package com.atpro.db

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import java.util.UUID
import com.atpro.db.dao.*
import com.atpro.db.entity.*

// ═══════════════════════════════════════════════════════════════
//  AtProDatabase — Room SQLite database
//  File: /data/data/com.atpro/databases/atpro.db
//  Thay thế hoàn toàn Supabase — không cần internet để đọc/ghi data
// ═══════════════════════════════════════════════════════════════

@Database(
    entities = [
        AccountEntity::class,
        SessionEntity::class,
        FarmLogEntity::class,
        ConfigEntity::class,
        SyncMetadataEntity::class,
        SyncOutboxEntity::class,
        AccountStatContributionEntity::class,
        BackupTombstoneEntity::class,
    ],
    version  = 5,
    exportSchema = false,
)
abstract class AtProDatabase : RoomDatabase() {

    abstract fun accountDao(): AccountDao
    abstract fun sessionDao(): SessionDao
    abstract fun logDao():     LogDao
    abstract fun configDao():  ConfigDao
    abstract fun syncMetadataDao(): SyncMetadataDao
    abstract fun syncOutboxDao(): SyncOutboxDao
    abstract fun accountStatContributionDao(): AccountStatContributionDao
    abstract fun backupTombstoneDao(): BackupTombstoneDao

    companion object {
        /**
         * Additive v1 to v2 migration. Existing rows are preserved; legacy sessions
         * receive stable UUIDs before the unique index is created.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE sessions ADD COLUMN syncId TEXT NOT NULL DEFAULT ''")
                val cursor = db.query("SELECT id FROM sessions WHERE syncId = ''")
                try {
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(0)
                        val syncId = UUID.randomUUID().toString()
                        db.execSQL("UPDATE sessions SET syncId = ? WHERE id = ?", arrayOf(syncId, id))
                    }
                } finally {
                    cursor.close()
                }
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_sessions_syncId ON sessions(syncId)")
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS sync_metadata (
                        id INTEGER NOT NULL PRIMARY KEY,
                        ownerUserId TEXT,
                        installationId TEXT NOT NULL,
                        lastRemoteRevision INTEGER NOT NULL,
                        lastSuccessfulSyncAt INTEGER,
                        lastChecksum TEXT,
                        formatVersion INTEGER NOT NULL,
                        syncStatus TEXT NOT NULL,
                        updatedAt INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS sync_outbox (
                        sequence INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        eventId TEXT NOT NULL,
                        dataset TEXT NOT NULL,
                        entityKey TEXT NOT NULL,
                        operation TEXT NOT NULL,
                        payloadJson TEXT,
                        createdAt INTEGER NOT NULL,
                        attempts INTEGER NOT NULL,
                        nextAttemptAt INTEGER NOT NULL,
                        lastErrorCode TEXT
                    )
                """.trimIndent())
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_sync_outbox_eventId ON sync_outbox(eventId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_outbox_createdAt ON sync_outbox(createdAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_outbox_dataset_entityKey ON sync_outbox(dataset, entityKey)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_outbox_nextAttemptAt ON sync_outbox(nextAttemptAt)")
                val installationId = UUID.randomUUID().toString()
                val now = System.currentTimeMillis()
                db.execSQL("""
                    INSERT INTO sync_metadata (
                        id, ownerUserId, installationId, lastRemoteRevision,
                        lastSuccessfulSyncAt, lastChecksum, formatVersion, syncStatus, updatedAt
                    ) VALUES (1, NULL, ?, 0, NULL, NULL, 1, 'IDLE', ?)
                """.trimIndent(), arrayOf(installationId, now))
            }
        }

        /**
         * Add owner-binding and revision-checkpoint timestamps without touching any user data.
         */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE sync_metadata ADD COLUMN ownerBoundAt INTEGER")
                db.execSQL("ALTER TABLE sync_metadata ADD COLUMN lastRevisionConfirmedAt INTEGER")
            }
        }

        /**
         * Split account status/stat timestamps and seed the current installation's
         * monotonic contribution from each existing local aggregate exactly once.
         */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE accounts ADD COLUMN statusUpdatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE accounts ADD COLUMN statsUpdatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE accounts SET statusUpdatedAt = updatedAt, statsUpdatedAt = updatedAt")
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS account_stat_contributions (
                        accountId TEXT NOT NULL,
                        installationId TEXT NOT NULL,
                        sessionsCount INTEGER NOT NULL,
                        totalLikes INTEGER NOT NULL,
                        totalFollows INTEGER NOT NULL,
                        totalVideos INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        PRIMARY KEY(accountId, installationId),
                        FOREIGN KEY(accountId) REFERENCES accounts(username)
                            ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_account_stat_contributions_accountId ON account_stat_contributions(accountId)")
                db.execSQL("""
                    INSERT OR IGNORE INTO account_stat_contributions (
                        accountId, installationId, sessionsCount, totalLikes,
                        totalFollows, totalVideos, updatedAt
                    )
                    SELECT accounts.username, sync_metadata.installationId,
                           accounts.sessionsCount, accounts.totalLikes,
                           accounts.totalFollows, accounts.totalVideos, accounts.updatedAt
                    FROM accounts
                    CROSS JOIN sync_metadata
                    WHERE sync_metadata.id = 1
                """.trimIndent())
            }
        }

        /** Durable delete markers; never garbage-collected until a causal watermark protocol exists. */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS backup_tombstones (
                        tombstoneId TEXT NOT NULL PRIMARY KEY,
                        dataset TEXT NOT NULL,
                        entityKey TEXT NOT NULL,
                        sourceInstallId TEXT NOT NULL,
                        deletedAt INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_backup_tombstones_dataset_entityKey ON backup_tombstones(dataset, entityKey)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_backup_tombstones_sourceInstallId ON backup_tombstones(sourceInstallId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_backup_tombstones_deletedAt ON backup_tombstones(deletedAt)")

                // Preserve pending legacy deletes before the new snapshot format is enabled.
                val pendingDeleteCount = db.query("""
                    SELECT COUNT(*) FROM sync_outbox
                    WHERE operation = 'DELETE'
                      AND dataset IN ('accounts', 'safeConfigs', 'schedules')
                """.trimIndent()).use { cursor ->
                    if (cursor.moveToFirst()) cursor.getLong(0) else 0L
                }

                db.execSQL("""
                    INSERT INTO backup_tombstones (
                        tombstoneId, dataset, entityKey, sourceInstallId, deletedAt
                    )
                    SELECT outbox.eventId, outbox.dataset, outbox.entityKey,
                           metadata.installationId, outbox.createdAt
                    FROM sync_outbox AS outbox
                    CROSS JOIN sync_metadata AS metadata
                    WHERE metadata.id = 1
                      AND outbox.operation = 'DELETE'
                      AND outbox.dataset IN ('accounts', 'safeConfigs', 'schedules')
                """.trimIndent())

                val migratedDeleteCount = db.query("SELECT changes()").use { cursor ->
                    if (cursor.moveToFirst()) cursor.getLong(0) else 0L
                }
                if (migratedDeleteCount != pendingDeleteCount) {
                    throw IllegalStateException(
                        "Could not safely backfill all pending Outbox DELETE events into backup_tombstones"
                    )
                }
            }
        }

        @Volatile
        private var INSTANCE: AtProDatabase? = null

        fun getInstance(context: Context): AtProDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AtProDatabase::class.java,
                    "atpro.db",
                )
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        // Fresh installs do not execute migrations; seed the singleton row here too.
                        db.execSQL("""
                            INSERT OR IGNORE INTO sync_metadata (
                                id, ownerUserId, installationId, lastRemoteRevision,
                                lastSuccessfulSyncAt, lastChecksum, formatVersion, syncStatus, updatedAt
                            ) VALUES (1, NULL, ?, 0, NULL, NULL, 1, 'IDLE', ?)
                        """.trimIndent(), arrayOf(UUID.randomUUID().toString(), System.currentTimeMillis()))
                    }
                })
                .build()
                .also { INSTANCE = it }
            }
    }
}
