package com.atpro.ui.config

import android.content.Context
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.*
import com.atpro.data.AccessibilitySettingsHelper
import com.atpro.data.LocalRepository
import com.atpro.notification.AtProNotificationManager
import com.atpro.notification.NotificationPrefs
import com.atpro.tasks.TaskAccountSelector
import com.atpro.tasks.TaskResult
import com.atpro.tasks.f4f.F4fAuth
import com.atpro.tasks.f4f.F4fAuthState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ConfigViewModel(
    private val repo: LocalRepository,
    /** v1.12.0: cần để đọc danh sách acc Follow4Follow cho mục "Tài khoản nhận nhiệm vụ" (null trong test). */
    private val appContext: Context? = null,
) : ViewModel() {

    private val _state   = MutableStateFlow(ConfigUiState())
    val state: StateFlow<ConfigUiState> = _state.asStateFlow()

    private val _saved   = MutableSharedFlow<Unit>(replay = 0)
    val saved: SharedFlow<Unit> = _saved

    init { load() }

    // ── v1.12.0: Tài khoản nhận nhiệm vụ ──────────────────────────────────────

    private val _taskAccounts = MutableStateFlow(TaskAccountsUi())
    val taskAccounts: StateFlow<TaskAccountsUi> = _taskAccounts.asStateFlow()

    /** Đọc danh sách acc đã liên kết Follow4Follow (quick-switch) + đối chiếu với acc đã có trên máy. */
    fun refreshTaskAccounts() {
        val ctx = appContext ?: return
        if (_taskAccounts.value.loading) return
        viewModelScope.launch {
            _taskAccounts.update { it.copy(loading = true, error = null, needLogin = false) }
            val loggedIn = F4fAuth.manager(ctx).state.value is F4fAuthState.LoggedIn
            if (!loggedIn) {
                _taskAccounts.value = TaskAccountsUi(loaded = true, needLogin = true)
                return@launch
            }
            val deviceKeys = withContext(Dispatchers.IO) { repo.getAccounts() }
                .map { TaskAccountSelector.key(it.username) }.toSet()
            when (val r = withContext(Dispatchers.IO) { F4fAuth.provider(ctx).listAccounts() }) {
                is TaskResult.Success -> {
                    val rows = r.data
                        .map { TaskAccountRow(it.username, TaskAccountSelector.key(it.username) in deviceKeys) }
                        .sortedWith(compareByDescending<TaskAccountRow> { it.onDevice }.thenBy { it.username.lowercase() })
                    _taskAccounts.value = TaskAccountsUi(loaded = true, rows = rows, deviceCount = deviceKeys.size)
                }
                is TaskResult.Error -> _taskAccounts.value = TaskAccountsUi(
                    loaded = true,
                    needLogin = r.isAuthError,
                    error = if (r.isAuthError) null else r.message,
                    deviceCount = deviceKeys.size,
                )
            }
        }
    }

    private fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }

            // v1.12.1: đọc cấu hình theo từng cụm nhỏ. Trước đây gộp hơn 100 lời gọi suspend vào MỘT
            // constructor ConfigUiState(...) → state machine của coroutine vượt 64KB bytecode
            // ("Method too large: ConfigViewModel$load$1.invokeSuspend") làm CI build release fail.
            var s = ConfigUiState(isLoading = false)
            s = loadPart1(s)
            s = loadPart2(s)
            s = loadPart3(s)
            s = loadPart4(s)
            s = loadPart5(s)

            // [v1.1.4.1 FIX] Dùng update thay vì assignment trực tiếp để giữ lại
            // trạng thái quyền đã được refreshPermissions() cập nhật. Nếu dùng
            // _state.value = s (với permissions mặc định = false), load() sẽ ghi đè
            // kết quả của refreshPermissions() nếu nó chạy trước khi load() hoàn tất.
            val loaded = s
            _state.update { prev ->
                loaded.copy(
                    accessibilityGranted = prev.accessibilityGranted,
                    overlayGranted       = prev.overlayGranted,
                    notificationGranted  = prev.notificationGranted,
                )
            }
        }
    }

    /** v1.12.1: cụm cấu hình 1/5 của load() — tách riêng để mỗi hàm suspend đủ nhỏ. */
    private suspend fun loadPart1(s: ConfigUiState): ConfigUiState {
        var watchMin = repo.getConfigDouble("watch_time_min", 3.0)
        var watchMax = repo.getConfigDouble("watch_time_max", 8.0)

        // ── VALIDATION: Bảo vệ chống crash Slider ──────────────────────
        // Compose Slider assert range.start <= range.endInclusive — vi phạm = crash ngay.
        if (watchMin > watchMax) {
            val temp = watchMin; watchMin = watchMax; watchMax = temp
        }
        if (watchMax - watchMin < 0.5) watchMax = watchMin + 0.5

        return s.copy(
            minutesPerAccount        = repo.getConfigInt   ("minutes_per_account", 5),
            watchMin                 = watchMin,
            watchMax                 = watchMax,
            enableRest               = repo.getConfigBool  ("enable_rest",         false),
            restMinutes              = repo.getConfigInt   ("rest_minutes",        2),
            maxBackAttempts          = repo.getConfigInt   ("max_back_attempts",   5),
            likeRate                 = repo.getConfigDouble("like_rate",           0.30).toFloat(),
            followRate               = repo.getConfigDouble("follow_rate",         0.15).toFloat(),
            // v1.2.9: Comment ngẫu nhiên
            commentRate               = repo.getConfigDouble("comment_rate",            0.0).toFloat(),
            commentTexts              = repo.getConfig      ("comment_texts", "")
                                            .split("||").map { it.trim() }.filter { it.isNotEmpty() },
            delayAfterComment         = repo.getConfigDouble("delay_after_comment",      1.5),
            maxCommentsPerHour        = repo.getConfigInt   ("max_comments_per_hour",     20),
            commentViewRate           = repo.getConfigDouble("comment_view_rate",         0.08).toFloat(),
            commentViewScrollMin      = repo.getConfigInt   ("comment_view_scroll_min",   1),
            commentViewScrollMax      = repo.getConfigInt   ("comment_view_scroll_max",   5),
            skipLive                 = repo.getConfigBool  ("skip_live",           true),
            skipAds                  = repo.getConfigBool  ("skip_ads",            true),
            normalizeEnabled         = repo.getConfigBool  ("normalize_enabled",   true),
            // [v1.1.8] Like content-aware
            likeAds                  = repo.getConfigBool  ("like_ads",            false),
        )
    }

    /** v1.12.1: cụm cấu hình 2/5 của load() — tách riêng để mỗi hàm suspend đủ nhỏ. */
    private suspend fun loadPart2(s: ConfigUiState): ConfigUiState {
        return s.copy(
            verifyAccount            = repo.getConfigBool  ("verify_account",      true),
            enableSystemNotifications = repo.getConfigBool ("enable_system_notifications", true),
            // [v1.12.0] Thông báo nâng cao
            notifAlerts               = repo.getConfigBool ("notif_alerts",   true),
            notifSessions             = repo.getConfigBool ("notif_sessions", true),
            notifAccounts             = repo.getConfigBool ("notif_accounts", true),
            notifTasks                = repo.getConfigBool ("notif_tasks",    true),
            notifQuietEnabled         = repo.getConfigBool ("notif_quiet_enabled", false),
            notifQuietStart           = repo.getConfigInt  ("notif_quiet_start", 23).coerceIn(0, 23),
            notifQuietEnd             = repo.getConfigInt  ("notif_quiet_end",   7).coerceIn(0, 23),
            // [v1.12.0] Chọn tài khoản nhận nhiệm vụ
            taskAccountMode           = repo.getConfig     ("task_account_mode", "AUTO").trim().uppercase().ifEmpty { "AUTO" },
            taskSelectedAccounts      = repo.getConfig     ("task_selected_accounts", ""),
            // [v1.1.9+] Tab ghé thăm
            inboxViewRate             = repo.getConfigDouble("inbox_view_rate",          0.0).toFloat(),
            inboxViewDurationSecs     = repo.getConfigInt   ("inbox_view_duration_secs", 15),
            shopViewRate              = repo.getConfigDouble("shop_view_rate",           0.0).toFloat(),
            shopScrollCount           = repo.getConfigInt   ("shop_scroll_count",        3),
            // [v1.2.0] Tim video theo nội dung
            likeByCaption             = repo.getConfigBool  ("like_by_caption",           false),
            captionKeywords           = repo.getConfig      ("caption_keywords",          ""),
            likeByHashtag             = repo.getConfigBool  ("like_by_hashtag",           false),
        )
    }

    /** v1.12.1: cụm cấu hình 3/5 của load() — tách riêng để mỗi hàm suspend đủ nhỏ. */
    private suspend fun loadPart3(s: ConfigUiState): ConfigUiState {
        // v1.11.0: khoảng xem của chế độ kiếm tiền (số nguyên giây, min < max để thanh kéo không lỗi)
        val likeRateNow   = s.likeRate   // đã đọc ở cụm trước (cùng khoá "like_rate", cùng mặc định 0.30)
        var taskWatchMin  = repo.getConfigInt("task_farm_watch_min_secs", s.watchMin.toInt().coerceAtLeast(1))
        var taskWatchMax  = repo.getConfigInt("task_farm_watch_max_secs", s.watchMax.toInt().coerceAtLeast(2))
        if (taskWatchMin > taskWatchMax) { val t = taskWatchMin; taskWatchMin = taskWatchMax; taskWatchMax = t }
        if (taskWatchMax - taskWatchMin < 1) taskWatchMax = taskWatchMin + 1

        return s.copy(
            hashtagKeywords           = repo.getConfig      ("hashtag_keywords",          ""),
            minLikesToLike            = repo.getConfigInt   ("min_likes_to_like",         0),   // v1.11.0
            // [v1.2.0] Tìm kiếm theo từ khoá
            searchEnabled             = repo.getConfigBool  ("search_enabled",            false),
            searchKeywords            = repo.getConfig      ("search_keywords",           ""),
            searchVideosPerSession    = repo.getConfigInt   ("search_videos_per_session",  3),
            searchRate                = repo.getConfigDouble("search_rate",               0.05).toFloat(),
            // [v1.2.1] Task mode
            taskJobType               = repo.getConfig      ("task_job_type",             "BOTH"),
            taskFarmBeforeJobSecs     = repo.getConfigInt   ("task_farm_before_job_secs",  60),
            taskJobDelaySecs          = repo.getConfigInt   ("task_job_delay_secs",         4),
            taskJobsPerAccount        = repo.getConfigInt   ("task_jobs_per_account",       5),
            taskMaxConsecFailures     = repo.getConfigInt   ("task_max_consec_failures",    3),
            // [v1.3.3] Nuôi acc ngắn sau job + nuôi acc lâu định kỳ
            taskFarmAfterJobMinSecs   = repo.getConfigInt   ("task_farm_after_job_min_secs", 5),
            taskFarmAfterJobMaxSecs   = repo.getConfigInt   ("task_farm_after_job_max_secs", 20),
            taskLongFarmEveryNJobs    = repo.getConfigInt   ("task_long_farm_every_n_jobs",  3),
            taskLongFarmDurationSecs  = repo.getConfigInt   ("task_long_farm_duration_secs", 180),
            // [v1.11.0] Nuôi acc trong lúc kiếm tiền
            taskFarmLikeRate          = repo.getConfigDouble("task_farm_like_rate",        likeRateNow.toDouble()).toFloat(),
            taskFarmWatchMinSecs      = taskWatchMin,
            taskFarmWatchMaxSecs      = taskWatchMax,
        )
    }

    /** v1.12.1: cụm cấu hình 4/5 của load() — tách riêng để mỗi hàm suspend đủ nhỏ. */
    private suspend fun loadPart4(s: ConfigUiState): ConfigUiState {
        return s.copy(
            taskFarmMinLikes          = repo.getConfigInt   ("task_farm_min_likes",        0),
            taskFarmLikeByHashtag     = repo.getConfigBool  ("task_farm_like_by_hashtag",  false),
            taskFarmHashtags          = repo.getConfig      ("task_farm_hashtags",         ""),
            taskFarmLikeByCaption     = repo.getConfigBool  ("task_farm_like_by_caption",  false),
            taskFarmCaptionKeywords   = repo.getConfig      ("task_farm_caption_keywords", ""),
            // [v1.2.4] Demo nuôi acc
            facebookNurtureDurationSecs = repo.getConfigInt   ("fb_nurture_duration_secs",  600),
            facebookLikeRate            = repo.getConfigDouble("fb_like_rate",              0.10).toFloat(),
            facebookReadTimeMinSecs     = repo.getConfigInt   ("fb_read_time_min_secs",      8),
            facebookReadTimeMaxSecs     = repo.getConfigInt   ("fb_read_time_max_secs",      25),
            // v1.3.0: Xem bình luận + Reels Facebook
            facebookCommentViewRate          = repo.getConfigDouble("fb_comment_view_rate",            0.05).toFloat(),
            facebookReelsViewRate            = repo.getConfigDouble("fb_reels_view_rate",              0.05).toFloat(),
            facebookReelsViewDurationMinSecs = repo.getConfigInt   ("fb_reels_view_duration_min_secs", 600),
            facebookReelsViewDurationMaxSecs = repo.getConfigInt   ("fb_reels_view_duration_max_secs", 1200),
            facebookReelsLikeRate            = repo.getConfigDouble("fb_reels_like_rate",              0.20).toFloat(),
            xNurtureDurationSecs        = repo.getConfigInt   ("x_nurture_duration_secs",   480),
            xLikeRate                   = repo.getConfigDouble("x_like_rate",               0.25).toFloat(),
            xRetweetRate                = repo.getConfigDouble("x_retweet_rate",            0.05).toFloat(),
            xReplyViewRate              = repo.getConfigDouble("x_reply_view_rate",         0.05).toFloat(),  // v1.3.0
            instagramNurtureDurationSecs= repo.getConfigInt   ("ig_nurture_duration_secs",  600),
            instagramLikeRate           = repo.getConfigDouble("ig_like_rate",              0.30).toFloat(),
        )
    }

    /** v1.12.1: cụm cấu hình 5/5 của load() — tách riêng để mỗi hàm suspend đủ nhỏ. */
    private suspend fun loadPart5(s: ConfigUiState): ConfigUiState {
        return s.copy(
            instagramFollowRate         = repo.getConfigDouble("ig_follow_rate",            0.08).toFloat(),
            instagramCommentViewRate    = repo.getConfigDouble("ig_comment_view_rate",      0.05).toFloat(), // v1.3.0
            threadsNurtureDurationSecs  = repo.getConfigInt   ("threads_nurture_duration_secs", 480),
            threadsLikeRate             = repo.getConfigDouble("threads_like_rate",         0.20).toFloat(),
            threadsReplyViewRate        = repo.getConfigDouble("threads_reply_view_rate",   0.05).toFloat(), // v1.3.0
            snapchatNurtureDurationSecs = repo.getConfigInt   ("snap_nurture_duration_secs", 360),
            snapchatStoryViewSecs       = repo.getConfigInt   ("snap_story_view_secs",       8),
            snapchatLikeRate            = repo.getConfigDouble("snap_like_rate",            0.20).toFloat(),  // v1.3.0
            discordWebhookUrl           = repo.getConfig      ("discord_webhook_url",       ""),
        )
    }

    fun set(block: ConfigUiState.() -> ConfigUiState) {
        _state.update { block(it).copy(isDirty = true) }
    }

    fun save() {
        val s = _state.value
        // v1.3.0: Bỏ hẳn cơ chế khoá "Experiment Mode" — mọi setting nuôi acc
        // (TikTok + Facebook + X/Instagram/Threads/Snapchat) giờ luôn ghi thẳng
        // giá trị người dùng chỉnh tay xuống DB, không còn ép về LockedDefaults.

        viewModelScope.launch {
            _state.update { it.copy(isSaving = true) }
            repo.setConfig("minutes_per_account",          "${s.minutesPerAccount}")
            repo.setConfig("watch_time_min",               "${s.watchMin}")
            repo.setConfig("watch_time_max",               "${s.watchMax}")
            repo.setConfig("enable_rest",                  "${s.enableRest}")
            repo.setConfig("rest_minutes",                 "${s.restMinutes}")
            repo.setConfig("max_back_attempts",            "${s.maxBackAttempts}")
            repo.setConfig("like_rate",                    "${s.likeRate}")
            repo.setConfig("follow_rate",                  "${s.followRate}")
            // v1.2.9: Comment ngẫu nhiên
            repo.setConfig("comment_rate",             "${s.commentRate}")
            repo.setConfig("comment_texts",            s.commentTexts.joinToString("||"))
            repo.setConfig("delay_after_comment",      "${s.delayAfterComment}")
            repo.setConfig("max_comments_per_hour",    "${s.maxCommentsPerHour}")
            // v1.2.9: Xem bình luận (thụ động)
            repo.setConfig("comment_view_rate",        "${s.commentViewRate}")
            repo.setConfig("comment_view_scroll_min",  "${s.commentViewScrollMin}")
            repo.setConfig("comment_view_scroll_max",  "${s.commentViewScrollMax}")
            repo.setConfig("skip_live",                    "${s.skipLive}")
            repo.setConfig("skip_ads",                     "${s.skipAds}")
            repo.setConfig("normalize_enabled",            "${s.normalizeEnabled}") // v1.2.6
            repo.setConfig("like_ads",                     "${s.likeAds}")  // [v1.1.8]
            repo.setConfig("verify_account",               "${s.verifyAccount}")
            repo.setConfig("enable_system_notifications",  "${s.enableSystemNotifications}")
            // [v1.12.0]
            repo.setConfig("notif_alerts",                 "${s.notifAlerts}")
            repo.setConfig("notif_sessions",               "${s.notifSessions}")
            repo.setConfig("notif_accounts",               "${s.notifAccounts}")
            repo.setConfig("notif_tasks",                  "${s.notifTasks}")
            repo.setConfig("notif_quiet_enabled",          "${s.notifQuietEnabled}")
            repo.setConfig("notif_quiet_start",            "${s.notifQuietStart}")
            repo.setConfig("notif_quiet_end",              "${s.notifQuietEnd}")
            repo.setConfig("task_account_mode",            s.taskAccountMode)
            repo.setConfig("task_selected_accounts",       s.taskSelectedAccounts)
            // [v1.1.9+] Tab ghé thăm
            repo.setConfig("inbox_view_rate",          "${s.inboxViewRate}")
            repo.setConfig("inbox_view_duration_secs", "${s.inboxViewDurationSecs}")
            repo.setConfig("shop_view_rate",           "${s.shopViewRate}")
            repo.setConfig("shop_scroll_count",        "${s.shopScrollCount}")
            // [v1.2.0] Tim video theo nội dung
            repo.setConfig("like_by_caption",          "${s.likeByCaption}")
            repo.setConfig("caption_keywords",         s.captionKeywords)
            repo.setConfig("like_by_hashtag",          "${s.likeByHashtag}")
            repo.setConfig("hashtag_keywords",         s.hashtagKeywords)
            repo.setConfig("min_likes_to_like",        "${s.minLikesToLike}")   // v1.11.0
            // [v1.2.0] Tìm kiếm theo từ khoá
            repo.setConfig("search_enabled",           "${s.searchEnabled}")
            repo.setConfig("search_keywords",          s.searchKeywords)
            repo.setConfig("search_videos_per_session","${s.searchVideosPerSession}")
            repo.setConfig("search_rate",              "${s.searchRate}")
            // [v1.2.1] Task mode
            repo.setConfig("task_job_type",            s.taskJobType)
            repo.setConfig("task_farm_before_job_secs","${s.taskFarmBeforeJobSecs}")
            repo.setConfig("task_job_delay_secs",      "${s.taskJobDelaySecs}")
            repo.setConfig("task_jobs_per_account",    "${s.taskJobsPerAccount}")
            repo.setConfig("task_max_consec_failures", "${s.taskMaxConsecFailures}")
            // [v1.3.3] Nuôi acc ngắn sau job + nuôi acc lâu định kỳ
            repo.setConfig("task_farm_after_job_min_secs", "${s.taskFarmAfterJobMinSecs}")
            repo.setConfig("task_farm_after_job_max_secs", "${s.taskFarmAfterJobMaxSecs}")
            repo.setConfig("task_long_farm_every_n_jobs",  "${s.taskLongFarmEveryNJobs}")
            repo.setConfig("task_long_farm_duration_secs", "${s.taskLongFarmDurationSecs}")
            // [v1.11.0] Nuôi acc trong lúc kiếm tiền
            repo.setConfig("task_farm_like_rate",          "${s.taskFarmLikeRate}")
            repo.setConfig("task_farm_watch_min_secs",     "${s.taskFarmWatchMinSecs}")
            repo.setConfig("task_farm_watch_max_secs",     "${s.taskFarmWatchMaxSecs}")
            repo.setConfig("task_farm_min_likes",          "${s.taskFarmMinLikes}")
            repo.setConfig("task_farm_like_by_hashtag",    "${s.taskFarmLikeByHashtag}")
            repo.setConfig("task_farm_hashtags",           s.taskFarmHashtags)
            repo.setConfig("task_farm_like_by_caption",    "${s.taskFarmLikeByCaption}")
            repo.setConfig("task_farm_caption_keywords",   s.taskFarmCaptionKeywords)
            // [v1.2.4] Demo nuôi acc
            repo.setConfig("fb_nurture_duration_secs",       "${s.facebookNurtureDurationSecs}")
            repo.setConfig("fb_like_rate",                   "${s.facebookLikeRate}")
            repo.setConfig("fb_read_time_min_secs",          "${s.facebookReadTimeMinSecs}")
            repo.setConfig("fb_read_time_max_secs",          "${s.facebookReadTimeMaxSecs}")
            // v1.3.0: Xem bình luận Facebook + Reels
            repo.setConfig("fb_comment_view_rate",           "${s.facebookCommentViewRate}")
            repo.setConfig("fb_reels_view_rate",             "${s.facebookReelsViewRate}")
            repo.setConfig("fb_reels_view_duration_min_secs","${s.facebookReelsViewDurationMinSecs}")
            repo.setConfig("fb_reels_view_duration_max_secs","${s.facebookReelsViewDurationMaxSecs}")
            repo.setConfig("fb_reels_like_rate",             "${s.facebookReelsLikeRate}")
            repo.setConfig("x_nurture_duration_secs",        "${s.xNurtureDurationSecs}")
            repo.setConfig("x_like_rate",                    "${s.xLikeRate}")
            repo.setConfig("x_retweet_rate",                 "${s.xRetweetRate}")
            repo.setConfig("x_reply_view_rate",              "${s.xReplyViewRate}")           // v1.3.0
            repo.setConfig("ig_nurture_duration_secs",       "${s.instagramNurtureDurationSecs}")
            repo.setConfig("ig_like_rate",                   "${s.instagramLikeRate}")
            repo.setConfig("ig_follow_rate",                 "${s.instagramFollowRate}")
            repo.setConfig("ig_comment_view_rate",           "${s.instagramCommentViewRate}")  // v1.3.0
            repo.setConfig("threads_nurture_duration_secs",  "${s.threadsNurtureDurationSecs}")
            repo.setConfig("threads_like_rate",              "${s.threadsLikeRate}")
            repo.setConfig("threads_reply_view_rate",        "${s.threadsReplyViewRate}")      // v1.3.0
            repo.setConfig("snap_nurture_duration_secs",     "${s.snapchatNurtureDurationSecs}")
            repo.setConfig("snap_story_view_secs",           "${s.snapchatStoryViewSecs}")
            repo.setConfig("snap_like_rate",                 "${s.snapchatLikeRate}")          // v1.3.0
            repo.setConfig("discord_webhook_url",            s.discordWebhookUrl)

            // Áp dụng ngay vào runtime manager
            AtProNotificationManager.prefs = NotificationPrefs(
                enabled        = s.enableSystemNotifications,
                alerts         = s.notifAlerts,
                sessions       = s.notifSessions,
                accounts       = s.notifAccounts,
                tasks          = s.notifTasks,
                quietEnabled   = s.notifQuietEnabled,
                quietStartHour = s.notifQuietStart,
                quietEndHour   = s.notifQuietEnd,
            )

            _state.update { it.copy(isSaving = false, isDirty = false) }
            _saved.emit(Unit)
        }
    }

    fun loadTikTokVersion(context: Context) {
        viewModelScope.launch {
            val version = try {
                listOf(
                    "com.zhiliaoapp.musically",
                    "com.ss.android.ugc.trill",
                    "com.ss.android.ugc.aweme",
                ).firstNotNullOfOrNull { pkg ->
                    runCatching {
                        context.packageManager.getPackageInfo(pkg, 0).versionName
                    }.getOrNull()?.let { "$pkg\n$it" }
                } ?: "Không tìm thấy TikTok"
            } catch (_: Exception) { "Không tìm thấy TikTok" }
            _state.update { it.copy(tikTokVersion = version) }
        }
    }

    /** Đọc trạng thái quyền hệ thống — gọi mỗi lần ConfigScreen hiển thị. */
    fun refreshPermissions(context: Context) {
        viewModelScope.launch {
            val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                NotificationManagerCompat.from(context).areNotificationsEnabled()
            } else true
            _state.update {
                it.copy(
                    accessibilityGranted = AccessibilitySettingsHelper.isAccessibilityEnabled(context),
                    overlayGranted       = AccessibilitySettingsHelper.isOverlayGranted(context),
                    notificationGranted  = notif,
                )
            }
        }
    }

    class Factory(private val ctx: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            ConfigViewModel(LocalRepository.getInstance(ctx.applicationContext), ctx.applicationContext) as T
    }
}

data class ConfigUiState(
    val isLoading:                Boolean = true,
    val isSaving:                 Boolean = false,
    val isDirty:                  Boolean = false,
    val minutesPerAccount:        Int     = 5,
    val watchMin:                 Double  = 3.0,
    val watchMax:                 Double  = 8.0,
    val enableRest:               Boolean = false,
    val restMinutes:              Int     = 2,
    val maxBackAttempts:          Int     = 5,
    val likeRate:                 Float   = 0.30f,
    val followRate:               Float   = 0.15f,
    // v1.2.9: Comment ngẫu nhiên
    val commentRate:              Float   = 0.0f,
    val commentTexts:             List<String> = emptyList(),
    val delayAfterComment:        Double  = 1.5,
    val maxCommentsPerHour:       Int     = 20,
    // v1.2.9: Xem bình luận (thụ động, không gõ)
    val commentViewRate:          Float   = 0.08f,
    val commentViewScrollMin:     Int     = 1,
    val commentViewScrollMax:     Int     = 5,
    val skipLive:                 Boolean = true,
    val skipAds:                  Boolean = true,
    // v1.2.6 — Bật/tắt chuẩn hoá display name / ID thuần số khi farm bắt đầu.
    val normalizeEnabled:         Boolean = true,
    // [v1.1.8] Like quảng cáo khi skipAds = false.
    val likeAds:                  Boolean = false,
    val verifyAccount:            Boolean = true,
    val enableSystemNotifications: Boolean = true,
    // [v1.12.0] Thông báo nâng cao: từng nhóm + giờ yên tĩnh (trong khoảng này thông báo không âm/rung)
    val notifAlerts:              Boolean = true,
    val notifSessions:            Boolean = true,
    val notifAccounts:            Boolean = true,
    val notifTasks:               Boolean = true,
    val notifQuietEnabled:        Boolean = false,
    val notifQuietStart:          Int     = 23,
    val notifQuietEnd:            Int     = 7,
    // [v1.12.0] Chọn tài khoản nhận nhiệm vụ: AUTO | SELECTED + danh sách username (phẩy)
    val taskAccountMode:          String  = "AUTO",
    val taskSelectedAccounts:     String  = "",
    val tikTokVersion:            String  = "Đang kiểm tra...",
    // [v1.1.9+] Tab ghé thăm
    val inboxViewRate:            Float   = 0.0f,
    val inboxViewDurationSecs:    Int     = 15,
    val shopViewRate:             Float   = 0.0f,
    val shopScrollCount:          Int     = 3,
    // [v1.2.0] Tim video theo nội dung
    val likeByCaption:            Boolean = false,
    val captionKeywords:          String  = "",
    val likeByHashtag:            Boolean = false,
    val hashtagKeywords:          String  = "",
    // v1.11.0: chỉ tim video có số tim >= ngưỡng (0 = tắt)
    val minLikesToLike:           Int     = 0,
    // [v1.2.0] Tìm kiếm theo từ khoá
    val searchEnabled:            Boolean = false,
    val searchKeywords:           String  = "",
    val searchVideosPerSession:   Int     = 3,
    val searchRate:               Float   = 0.05f,
    // [v1.2.1] Task mode — làm nhiệm vụ kiếm tiền
    val taskJobType:              String  = "BOTH",   // "LIKE" | "FOLLOW" | "BOTH"
    val taskFarmBeforeJobSecs:    Int     = 60,
    val taskJobDelaySecs:         Int     = 4,
    val taskJobsPerAccount:       Int     = 5,
    val taskMaxConsecFailures:    Int     = 3,
    // [v1.3.3] Nuôi acc ngắn sau job + nuôi acc lâu định kỳ
    val taskFarmAfterJobMinSecs:  Int     = 5,
    val taskFarmAfterJobMaxSecs:  Int     = 20,
    val taskLongFarmEveryNJobs:   Int     = 3,
    val taskLongFarmDurationSecs: Int     = 180,
    // [v1.11.0] Nuôi acc trong lúc kiếm tiền — bộ thiết lập riêng
    val taskFarmLikeRate:         Float   = 0.30f,
    val taskFarmWatchMinSecs:     Int     = 3,
    val taskFarmWatchMaxSecs:     Int     = 8,
    val taskFarmMinLikes:         Int     = 0,
    val taskFarmLikeByHashtag:    Boolean = false,
    val taskFarmHashtags:         String  = "",
    val taskFarmLikeByCaption:    Boolean = false,
    val taskFarmCaptionKeywords:  String  = "",
    // [v1.2.4] Demo nuôi tài khoản các nền tảng khác
    val facebookNurtureDurationSecs: Int   = 180,
    val facebookLikeRate:            Float = 0.10f,
    val facebookReadTimeMinSecs:     Int   = 8,
    val facebookReadTimeMaxSecs:     Int   = 25,
    // v1.3.0: Xem bình luận + Reels Facebook
    val facebookCommentViewRate:          Float = 0.05f,
    val facebookReelsViewRate:            Float = 0.05f,
    val facebookReelsViewDurationMinSecs: Int   = 600,
    val facebookReelsViewDurationMaxSecs: Int   = 1200,
    val facebookReelsLikeRate:            Float = 0.20f,
    val xNurtureDurationSecs:        Int   = 120,
    val xLikeRate:                   Float = 0.25f,
    val xRetweetRate:                Float = 0.05f,
    val xReplyViewRate:              Float = 0.05f,   // v1.3.0
    val instagramNurtureDurationSecs:Int   = 180,
    val instagramLikeRate:           Float = 0.30f,
    val instagramFollowRate:         Float = 0.08f,
    val instagramCommentViewRate:    Float = 0.05f,   // v1.3.0
    val threadsNurtureDurationSecs:  Int   = 120,
    val threadsLikeRate:             Float = 0.20f,
    val threadsReplyViewRate:        Float = 0.05f,   // v1.3.0
    val snapchatNurtureDurationSecs: Int   = 90,
    val snapchatStoryViewSecs:       Int   = 8,
    val snapchatLikeRate:            Float = 0.20f,   // v1.3.0

    // v1.3.0: Thông báo Discord
    val discordWebhookUrl: String = "",
    // ── Permission state (read-only, refreshed via refreshPermissions()) ──
    val accessibilityGranted:     Boolean = false,
    val overlayGranted:           Boolean = false,
    val notificationGranted:      Boolean = false,
)

// v1.3.0: Đã bỏ hẳn cơ chế khoá "Experiment Mode" (gõ "Experiment" để mở khoá) —
// mọi setting nuôi acc (TikTok + Facebook + X/Instagram/Threads/Snapchat) giờ
// luôn hiện slider chỉnh tay được, không còn trạng thái khoá/LockedDefaults nữa.
// Dòng "experiment" trong danh sách comment (nếu người dùng từng gõ ở bản cũ)
// vẫn được lọc ra khỏi comment thật sự — xem AutomationEngine.doComment().

/** v1.12.0: một tài khoản F4F trong mục "Tài khoản nhận nhiệm vụ"; [onDevice] = đã có trong danh sách acc trên máy. */
data class TaskAccountRow(val username: String, val onDevice: Boolean)

data class TaskAccountsUi(
    val loading: Boolean = false,
    val loaded: Boolean = false,
    val needLogin: Boolean = false,
    val error: String? = null,
    val rows: List<TaskAccountRow> = emptyList(),
    val deviceCount: Int = 0,
)
