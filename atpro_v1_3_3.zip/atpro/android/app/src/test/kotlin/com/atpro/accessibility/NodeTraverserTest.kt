package com.atpro.accessibility

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import io.mockk.*
import org.junit.*
import org.junit.Assert.*

/**
 * NodeTraverserTest — unit tests cho NodeTraverser traversal + detection logic.
 *
 * Kỹ thuật: MockK để tạo AccessibilityNodeInfo fake trees.
 * Không cần Robolectric — tất cả Android class calls đều được mock.
 *
 * Cây node được xây dựng bằng helper `\[node()\]` — tạo một MockK
 * AccessibilityNodeInfo với text, resourceId, clickable, children.
 * `traverseAll()` bên trong NodeTraverser dùng BFS qua childCount + getChild(i),
 * cả hai đều được mock đúng.
 *
 * Tests:
 *   - findByText: match, no match, ignoreCase, exact
 *   - findByResourceId: match, partial match
 *   - hasNavBar: detected via text, detected via resourceId, not detected
 *   - detectCheckpoint: positive, negative
 *   - parseAccountList: extracts @usernames
 *   - detectPopup: VERIFY_1234 (4 EditText), ACCOUNT_SWITCH (≥2 @usernames),
 *     ACCOUNT_UPDATE_PROMPT (v1.3.1 — ưu tiên trước ACCOUNT_SWITCH), NONE
 *   - detectLive: via resourceId, not detected
 */
class NodeTraverserTest {

    // ── Tree builder ──────────────────────────────────────────

    /**
     * Tạo mock AccessibilityNodeInfo.
     *
     * Mô phỏng đủ interface để NodeTraverser.traverseAll() hoạt động:
     *   - childCount / getChild(i)
     *   - text / contentDescription / viewIdResourceName / className
     *   - isClickable / isEnabled / getBoundsInScreen
     */
    private fun node(
        text:      String?                       = null,
        desc:      String?                       = null,
        id:        String?                       = null,
        cls:       String                        = "android.widget.TextView",
        clickable: Boolean                       = false,
        children:  List<AccessibilityNodeInfo>   = emptyList(),
        bounds:    Rect?                          = null,
    ): AccessibilityNodeInfo = mockk(relaxed = true) {
        every { this@mockk.text }                returns text?.toCharSequence()
        every { contentDescription }             returns desc?.toCharSequence()
        every { viewIdResourceName }             returns id
        every { className }                      returns cls.toCharSequence()
        every { isClickable }                    returns clickable
        every { isEnabled }                      returns true
        every { childCount }                     returns children.size
        children.forEachIndexed { i, child ->
            every { getChild(i) } returns child
        }
        if (bounds != null) {
            every { getBoundsInScreen(any()) } answers {
                firstArg<Rect>().set(bounds)
            }
        } else {
            every { getBoundsInScreen(any()) } just Runs
        }
    }

    private fun String.toCharSequence(): CharSequence = this

    // ── findByText ────────────────────────────────────────────

    @Test
    fun `findByText returns node when text matches case-insensitive`() {
        val target = node(text = "Follow", clickable = true)
        val root   = node(children = listOf(target))

        val result = NodeTraverser.findByText(root, "follow")

        assertNotNull(result)
        assertEquals("Follow", result!!.text)
        assertTrue(result.isClickable)
    }

    @Test
    fun `findByText returns null when no node matches`() {
        val child = node(text = "Like")
        val root  = node(children = listOf(child))

        val result = NodeTraverser.findByText(root, "NonExistent")

        assertNull(result)
    }

    @Test
    fun `findByText with exact=true only matches full text`() {
        val child = node(text = "Follow now")
        val root  = node(children = listOf(child))

        // Partial text should NOT match with exact=true
        val partial = NodeTraverser.findByText(root, "follow", exact = true)
        assertNull("Partial text must not match in exact mode", partial)

        // Full exact text must match
        val exact = NodeTraverser.findByText(root, "Follow now", exact = true, ignoreCase = false)
        assertNotNull("Exact text must match", exact)
    }

    @Test
    fun `findByText searches contentDescription when text is null`() {
        val target = node(text = null, desc = "Chuyển đổi tài khoản")
        val root   = node(children = listOf(target))

        val result = NodeTraverser.findByText(root, "chuyển đổi tài khoản")
        assertNotNull(result)
    }

    @Test
    fun `findByText returns null for null root`() {
        assertNull(NodeTraverser.findByText(null, "anything"))
    }

    // ── findByResourceId ──────────────────────────────────────

    @Test
    fun `findByResourceId finds node by partial resource id`() {
        val target = node(id = "com.zhiliaoapp.musically:id/tab_bar")
        val root   = node(children = listOf(target))

        val result = NodeTraverser.findByResourceId(root, "tab_bar")
        assertNotNull(result)
        assertEquals("com.zhiliaoapp.musically:id/tab_bar", result!!.resourceId)
    }

    @Test
    fun `findByResourceId returns null when no id matches`() {
        val child = node(id = "com.pkg:id/some_other_view")
        val root  = node(children = listOf(child))

        assertNull(NodeTraverser.findByResourceId(root, "nav_bar"))
    }

    // ── hasNavBar ─────────────────────────────────────────────

    @Test
    fun `hasNavBar returns true when at least 2 nav tab texts found`() {
        val forYou    = node(text = "For You")
        val following = node(text = "Following")
        val profile   = node(text = "Profile")
        val root      = node(children = listOf(forYou, following, profile))

        assertTrue(NodeTraverser.hasNavBar(root))
    }

    @Test
    fun `hasNavBar returns true when nav resourceId found`() {
        val navBar = node(id = "com.zhiliaoapp.musically:id/tab_bar")
        val root   = node(children = listOf(navBar))

        assertTrue(NodeTraverser.hasNavBar(root))
    }

    @Test
    fun `hasNavBar returns false when fewer than 2 nav items`() {
        val oneTab = node(text = "For You")
        val root   = node(children = listOf(oneTab))

        assertFalse(NodeTraverser.hasNavBar(root))
    }

    @Test
    fun `hasNavBar returns false for null root`() {
        assertFalse(NodeTraverser.hasNavBar(null))
    }

    // ── detectCheckpoint ──────────────────────────────────────

    @Test
    fun `detectCheckpoint returns true when checkpoint keyword found`() {
        val warning = node(text = "Verify your account to continue")
        val root    = node(children = listOf(warning))

        assertTrue(NodeTraverser.detectCheckpoint(root))
    }

    @Test
    fun `detectCheckpoint returns true for Vietnamese keyword`() {
        val warning = node(text = "Tài khoản bị khóa, vui lòng xác minh")
        val root    = node(children = listOf(warning))

        assertTrue(NodeTraverser.detectCheckpoint(root))
    }

    @Test
    fun `detectCheckpoint returns false for normal feed screen`() {
        val video = node(text = "Check out this amazing video!")
        val root  = node(children = listOf(video))

        assertFalse(NodeTraverser.detectCheckpoint(root))
    }

    @Test
    fun `detectCheckpoint returns false for null root`() {
        assertFalse(NodeTraverser.detectCheckpoint(null))
    }

    // ── parseAccountList ──────────────────────────────────────

    @Test
    fun `parseAccountList extracts usernames starting with @`() {
        val u1   = node(text = "@alice")
        val u2   = node(text = "@bob_farm")
        val u3   = node(text = "Chuyển đổi tài khoản")  // non-username — ignored
        val root = node(children = listOf(u1, u2, u3))

        val result = NodeTraverser.parseAccountList(root)

        assertEquals(2, result.size)
        assertTrue("alice" in result)
        assertTrue("bob_farm" in result)
    }

    @Test
    fun `parseAccountList ignores short @ strings`() {
        val short = node(text = "@a")    // length ≤ 2 including @ — ignored
        val valid = node(text = "@xyz")
        val root  = node(children = listOf(short, valid))

        val result = NodeTraverser.parseAccountList(root)
        assertEquals(1, result.size)
        assertEquals("xyz", result[0])
    }

    @Test
    fun `parseAccountList deduplicates usernames`() {
        val u1   = node(text = "@alice")
        val u2   = node(text = "@alice")  // duplicate
        val root = node(children = listOf(u1, u2))

        assertEquals(1, NodeTraverser.parseAccountList(root).size)
    }

    // ── detectPopup ───────────────────────────────────────────

    @Test
    fun `detectPopup returns VERIFY_1234 when exactly 4 EditTexts found`() {
        val edits = (1..4).map { node(cls = "android.widget.EditText") }
        val root  = node(children = edits)

        val info = NodeTraverser.detectPopup(root)

        assertTrue(info.detected)
        assertEquals(NodeTraverser.PopupType.VERIFY_1234, info.type)
    }

    @Test
    fun `detectPopup returns ACCOUNT_SWITCH when 2+ @usernames AND switch container present`() {
        // Switch popup thật: có @username nodes + label "Chuyển đổi tài khoản"
        // isOnFeedTab() = false (không có nav bar / video layout ID)
        val u1   = node(text = "@alice_farm")
        val u2   = node(text = "@bob_farm")
        val btn  = node(text = "Chuyển đổi tài khoản")
        val root = node(children = listOf(u1, u2, btn))

        val info = NodeTraverser.detectPopup(root)

        assertTrue(info.detected)
        assertEquals(NodeTraverser.PopupType.ACCOUNT_SWITCH, info.type)
    }

    @Test
    fun `detectPopup returns NONE for feed screen with @username in video description`() {
        // Feed false-positive: video caption và duet tag có @username nhưng không có switch container.
        // [FIX v1.0.9] Trước kia trả về ACCOUNT_SWITCH — giờ phải là NONE.
        val caption  = node(text = "@creator_name check this out!")
        val duetTag  = node(text = "@another_user duet")
        val likeBtn  = node(text = "thích", clickable = true)
        val shareBtn = node(text = "chia sẻ", clickable = true)
        val root     = node(children = listOf(caption, duetTag, likeBtn, shareBtn))

        val info = NodeTraverser.detectPopup(root)

        // Không có "switch account" / "chuyển đổi tài khoản" container → không phải switch popup
        assertFalse(info.detected)
        assertNotEquals(NodeTraverser.PopupType.ACCOUNT_SWITCH, info.type)
    }

    @Test
    fun `detectPopup returns NONE when 2+ @usernames found but user is on feed tab`() {
        // Edge case: switch container có mặt nhưng isOnFeedTab() = true (overlay chưa fully dismissed).
        // hasSwitchContainer=true AND onFeed=true → không trả ACCOUNT_SWITCH.
        val u1         = node(text = "@user_one")
        val u2         = node(text = "@user_two")
        val switchNode = node(id = "com.zhiliaoapp.musically:id/switch_account")
        val homeTab    = node(text = "Trang chủ", desc = "Trang chủ")
        val profileTab = node(text = "Hồ sơ")
        val root       = node(children = listOf(u1, u2, switchNode, homeTab, profileTab))

        val info = NodeTraverser.detectPopup(root)

        assertNotEquals(NodeTraverser.PopupType.ACCOUNT_SWITCH, info.type)
    }

    @Test
    fun `detectPopup returns ACCOUNT_UPDATE_PROMPT when update dialog overlays the switch list`() {
        // Hình 1 (v1.3.1): dialog "Tài khoản của bạn cần được cập nhật" đè lên NGAY
        // TRÊN danh sách switch-account — cây node vẫn còn đủ @username + label
        // "Chuyển đổi tài khoản" (danh sách nằm phía sau dialog), nên PHẢI ưu tiên
        // ACCOUNT_UPDATE_PROMPT trước, không được rơi vào nhánh ACCOUNT_SWITCH.
        val u1      = node(text = "@alice_farm")
        val u2      = node(text = "@bob_farm")
        val listLbl = node(text = "Chuyển đổi tài khoản")
        val prompt  = node(text = "Tài khoản của bạn cần được cập nhật")
        val laterBtn = node(text = "Để sau", clickable = true)
        val root    = node(children = listOf(u1, u2, listLbl, prompt, laterBtn))

        val info = NodeTraverser.detectPopup(root)

        assertTrue(info.detected)
        assertEquals(NodeTraverser.PopupType.ACCOUNT_UPDATE_PROMPT, info.type)
        assertNotEquals(NodeTraverser.PopupType.ACCOUNT_SWITCH, info.type)
    }

    @Test
    fun `detectPopup returns ACCOUNT_UPDATE_PROMPT via phone-link text without switch list`() {
        val linkText = node(text = "Liên kết số điện thoại hoặc email")
        val root     = node(children = listOf(linkText))

        val info = NodeTraverser.detectPopup(root)

        assertTrue(info.detected)
        assertEquals(NodeTraverser.PopupType.ACCOUNT_UPDATE_PROMPT, info.type)
    }

    @Test
    fun `detectPopup returns NONE for normal feed screen`() {
        val video = node(text = "Watch this cool video")
        val like  = node(text = "Like", clickable = true)
        val root  = node(children = listOf(video, like))

        val info = NodeTraverser.detectPopup(root)

        assertFalse(info.detected)
        assertEquals(NodeTraverser.PopupType.NONE, info.type)
    }

    // ── detectLive ────────────────────────────────────────────

    @Test
    fun `detectLive returns true when live resourceId found`() {
        val liveView = node(id = "com.zhiliaoapp.musically:id/liveroom_gift_panel")
        val root     = node(children = listOf(liveView))

        assertTrue(NodeTraverser.detectLive(root))
    }

    @Test
    fun `detectLive returns false for non-live content`() {
        val video = node(text = "Regular video content")
        val root  = node(children = listOf(video))

        assertFalse(NodeTraverser.detectLive(root))
    }

    // ── findAllByClass ────────────────────────────────────────

    @Test
    fun `findAllByClass returns all nodes of given class`() {
        val btn1 = node(cls = "android.widget.Button", text = "OK")
        val btn2 = node(cls = "android.widget.Button", text = "Cancel")
        val txt  = node(cls = "android.widget.TextView", text = "Title")
        val root = node(children = listOf(btn1, btn2, txt))

        val buttons = NodeTraverser.findAllByClass(root, "Button")

        assertEquals(2, buttons.size)
    }

    // ── detectPopup: DAILY_LIMIT vs VERIFY_1234 (v1.1.8) ─────

    @Test
    fun `detectPopup returns DAILY_LIMIT when 4 EditTexts AND daily limit signal present`() {
        // Màn hình Daily Limit: 4 EditText + nút "Quay lại TikTok"
        val edits   = (1..4).map { node(cls = "android.widget.EditText") }
        val signal  = node(text = "Quay lại TikTok", clickable = true)
        val root    = node(children = edits + signal)

        val info = NodeTraverser.detectPopup(root)

        assertTrue(info.detected)
        assertEquals(NodeTraverser.PopupType.DAILY_LIMIT, info.type)
    }

    @Test
    fun `detectPopup returns VERIFY_1234 when 4 EditTexts and no daily limit signal`() {
        // Màn hình VERIFY_1234: 4 EditText, KHÔNG có text daily limit
        val edits = (1..4).map { node(cls = "android.widget.EditText") }
        val root  = node(children = edits)

        val info = NodeTraverser.detectPopup(root)

        assertTrue(info.detected)
        assertEquals(NodeTraverser.PopupType.VERIFY_1234, info.type)
    }

    @Test
    fun `detectDailyLimitScreen returns true when return button found`() {
        val btn  = node(text = "Quay lại TikTok", clickable = true)
        val root = node(children = listOf(btn))

        assertTrue(NodeTraverser.detectDailyLimitScreen(root))
    }

    @Test
    fun `detectDailyLimitScreen returns true via keyword fallback`() {
        val txt  = node(text = "bạn đã sẵn sàng đóng tiktok")
        val root = node(children = listOf(txt))

        assertTrue(NodeTraverser.detectDailyLimitScreen(root))
    }

    @Test
    fun `detectDailyLimitScreen returns false for normal feed screen`() {
        val video = node(text = "Regular video content")
        val root  = node(children = listOf(video))

        assertFalse(NodeTraverser.detectDailyLimitScreen(root))
    }

    @Test
    fun `findReturnToTikTokButton returns node for VN text`() {
        val btn  = node(text = "Quay lại TikTok", clickable = true)
        val root = node(children = listOf(btn))

        val result = NodeTraverser.findReturnToTikTokButton(root)

        assertNotNull(result)
        assertEquals("Quay lại TikTok", result!!.text)
    }

    @Test
    fun `findReturnToTikTokButton returns null when button absent`() {
        val root = node(children = listOf(node(text = "Quay lại ngay bây giờ", clickable = true)))

        // "Quay lại ngay bây giờ" là wellbeing button — không khớp daily limit
        assertNull(NodeTraverser.findReturnToTikTokButton(root))
    }

    // ── findProfileTab (v1.3.2 — giới hạn quét vào dải Y đáy màn hình) ──

    @Test
    fun `findProfileTab ignores recommend tab resource-id false match via me substring`() {
        // resource-id "tab_recommend" (tab "Đề xuất") chứa substring "me" —
        // trước v1.3.2, PROFILE_IDS chứa "me" khiến node này bị nhận nhầm là
        // nút Profile. Tab "Đề xuất" nằm Ở TRÊN màn hình (y=100/2000), KHÔNG
        // phải nav bar đáy màn hình → phải bị loại khỏi ứng viên.
        val recommendTab = node(
            id = "tab_recommend", clickable = true,
            bounds = Rect(0, 80, 200, 120),
        )
        // Nút Profile thật nằm trong nav bar ở đáy màn hình (y ~ 1900/2000),
        // chỉ có text (không có resource-id) — mô phỏng biến thể TikTok chỉ
        // expose text thuần cho tab này.
        val profileBtn = node(
            text = "Hồ sơ", clickable = true,
            bounds = Rect(800, 1880, 1000, 1960),
        )
        val root = node(children = listOf(recommendTab, profileBtn))

        val result = NodeTraverser.findProfileTab(root, screenHeight = 2000)

        assertNotNull(result)
        assertEquals("Hồ sơ", result!!.text)
    }

    @Test
    fun `findProfileTab ignores comment button resource-id false match mid-feed`() {
        // resource-id "btn_comment" (nút bình luận trên video) cũng chứa
        // substring "me" — nằm giữa màn hình trong thanh action rail của
        // video (y=900/2000), không phải nav bar → không được bấm nhầm thay
        // vì Hồ sơ thật ở đáy màn hình (khớp qua text "Hồ sơ").
        val commentBtn = node(
            id = "btn_comment", clickable = true,
            bounds = Rect(900, 880, 980, 940),
        )
        val profileBtn = node(
            text = "Hồ sơ", clickable = true,
            bounds = Rect(800, 1880, 1000, 1960),
        )
        val root = node(children = listOf(commentBtn, profileBtn))

        val result = NodeTraverser.findProfileTab(root, screenHeight = 2000)

        assertNotNull(result)
        assertEquals("Hồ sơ", result!!.text)
    }

    @Test
    fun `findProfileTab falls back to full-tree scan when screenHeight not provided`() {
        // Không truyền screenHeight (giá trị mặc định) → giữ hành vi cũ, không regress
        // các call site chưa cập nhật để truyền screen height.
        val profileBtn = node(id = "tab_profile", clickable = true)
        val root = node(children = listOf(profileBtn))

        val result = NodeTraverser.findProfileTab(root)

        assertNotNull(result)
        assertEquals("tab_profile", result!!.resourceId)
    }

    @Test
    fun `findProfileTab falls back to full-tree scan when nothing found in nav bar band`() {
        // Nút Profile nằm ngoài dải ước tính (vd thiết bị có nav bar cao hơn) —
        // vẫn phải tìm được qua fallback quét toàn cây, không được trả về null.
        val profileBtn = node(
            id = "tab_profile", clickable = true,
            bounds = Rect(800, 1500, 1000, 1580),   // y=1540, ngoài dải 0.82*2000=1640
        )
        val root = node(children = listOf(profileBtn))

        val result = NodeTraverser.findProfileTab(root, screenHeight = 2000)

        assertNotNull(result)
        assertEquals("tab_profile", result!!.resourceId)
    }
}
