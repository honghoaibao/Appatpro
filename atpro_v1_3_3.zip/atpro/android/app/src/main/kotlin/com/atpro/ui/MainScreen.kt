package com.atpro.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.atpro.ui.accounts.AccountsScreen
import com.atpro.ui.accounts.AccountsViewModel
import com.atpro.ui.dashboard.DashboardScreen
import com.atpro.ui.dashboard.DashboardViewModel
import com.atpro.ui.dashboard.UpdateAvailableDialog
import com.atpro.ui.golike.GolikeLoginWebActivity
import com.atpro.ui.schedule.ScheduleScreen
import com.atpro.ui.schedule.ScheduleViewModel
import com.atpro.ui.services.ServicesScreen
import com.atpro.ui.stats.StatsScreen
import com.atpro.ui.stats.StatsViewModel

// ── Design tokens ────────────────────────────────────────────
private val BgDark    = Color(0xFF0D0D14)
private val NavBg     = Color(0xFF13131F)
private val Purple    = Color(0xFF6C63FF)
private val TextMuted = Color(0xFF6B7280)

// ─────────────────────────────────────────────────────────────
//  Tab definition
//  v1.2.9: Xóa LOGS — Nhật ký chuyển vào Cài đặt.
// ─────────────────────────────────────────────────────────────

private enum class Tab(
    val label: String,
    val icon:  ImageVector,
) {
    DASHBOARD("Dashboard",  Icons.Rounded.Home),
    SERVICES ("Dịch vụ",   Icons.Rounded.Layers),
    STATS    ("Thống kê",  Icons.Rounded.BarChart),
    ACCOUNTS ("Tài khoản", Icons.Rounded.ManageAccounts),
    SCHEDULE ("Lịch",      Icons.Rounded.Schedule),
}

// ─────────────────────────────────────────────────────────────
//  MainScreen — shell duy nhất chứa tất cả tab
// ─────────────────────────────────────────────────────────────

@Composable
fun MainScreen(
    dashboardVm: DashboardViewModel,
    statsVm:     StatsViewModel,
    accountsVm:  AccountsViewModel,
    scheduleVm:  ScheduleViewModel,
) {
    var selectedTab by remember { mutableStateOf(Tab.DASHBOARD) }
    val dashboardState by dashboardVm.uiState.collectAsStateWithLifecycle()

    // v1.3.4: Đăng nhập Golike qua WebView — GolikeLoginWebActivity tự lưu
    // token nội bộ (repo.saveWebToken) khi RESULT_OK; ở đây chỉ cần trigger
    // refresh UI ngay qua onGolikeWebLoginResult(), không phải đợi poll 30s.
    val context = LocalContext.current
    val golikeLoginLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        dashboardVm.onGolikeWebLoginResult(
            result.data?.getStringExtra(GolikeLoginWebActivity.EXTRA_TOKEN),
        )
    }

    // v1.2.9: Kiểm tra phiên bản mới ở cấp MainScreen (không phải DashboardScreen) —
    // chạy đúng 1 lần cho cả phiên app, không bị huỷ/refire khi chuyển tab qua lại.
    // Dialog cũng được render ở dưới (ngoài Scaffold) nên luôn hiện đè lên mọi tab,
    // không chỉ riêng tab Dashboard.
    LaunchedEffect(Unit) { dashboardVm.checkForUpdate() }

    Scaffold(
        containerColor      = BgDark,
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            NavigationBar(
                modifier       = Modifier.navigationBarsPadding(),
                containerColor = NavBg,
                tonalElevation = 0.dp,
            ) {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick  = { selectedTab = tab },
                        icon     = {
                            Icon(
                                tab.icon,
                                contentDescription = tab.label,
                                modifier = Modifier.size(22.dp),
                            )
                        },
                        label = {
                            // v1.2.9: softWrap=false + Ellipsis phòng mất chữ trên màn nhỏ
                            Text(
                                tab.label,
                                fontSize  = 10.sp,
                                maxLines  = 1,
                                softWrap  = false,
                                overflow  = TextOverflow.Ellipsis,
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor   = Purple,
                            selectedTextColor   = Purple,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor      = Purple.copy(alpha = 0.12f),
                        ),
                    )
                }
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding()),
        ) {
            AnimatedContent(
                targetState   = selectedTab,
                transitionSpec = {
                    val forward = targetState.ordinal > initialState.ordinal
                    (fadeIn(tween(220)) + slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) {
                        if (forward) it / 12 else -it / 12
                    }) togetherWith (fadeOut(tween(160)) + slideOutHorizontally(tween(220)) {
                        if (forward) -it / 12 else it / 12
                    })
                },
                label = "tab_transition",
            ) { tab ->
                when (tab) {
                    Tab.DASHBOARD -> DashboardScreen(vm = dashboardVm)

                    Tab.SERVICES  -> ServicesScreen(
                        isGolikeLoggedIn    = dashboardVm.uiState.collectAsState().value.isGolikeLoggedIn,
                        golikeCoin          = dashboardVm.uiState.collectAsState().value.golikeCoin,
                        golikeHoldCoin      = dashboardVm.uiState.collectAsState().value.golikeHoldCoin,
                        onSaveGolikeToken   = dashboardVm::saveGolikeToken,
                        onClearGolikeToken  = dashboardVm::clearGolikeToken,
                        onOpenGolikeWebLogin = {
                            golikeLoginLauncher.launch(Intent(context, GolikeLoginWebActivity::class.java))
                        },
                        onOpenFarmService   = {
                            dashboardVm.setServiceMode(com.atpro.automation.ServiceMode.FARM)
                            selectedTab = Tab.DASHBOARD
                        },
                        onOpenTaskService   = {
                            dashboardVm.setServiceMode(com.atpro.automation.ServiceMode.TASK)
                            selectedTab = Tab.DASHBOARD
                        },
                        onOpenFacebookService = {
                            dashboardVm.setServiceMode(com.atpro.automation.ServiceMode.FACEBOOK_NURTURE)
                            selectedTab = Tab.DASHBOARD
                        },
                        onOpenXService = {
                            dashboardVm.setServiceMode(com.atpro.automation.ServiceMode.X_NURTURE)
                            selectedTab = Tab.DASHBOARD
                        },
                        onOpenInstagramService = {
                            dashboardVm.setServiceMode(com.atpro.automation.ServiceMode.INSTAGRAM_NURTURE)
                            selectedTab = Tab.DASHBOARD
                        },
                        onOpenThreadsService = {
                            dashboardVm.setServiceMode(com.atpro.automation.ServiceMode.THREADS_NURTURE)
                            selectedTab = Tab.DASHBOARD
                        },
                        onOpenSnapchatService = {
                            dashboardVm.setServiceMode(com.atpro.automation.ServiceMode.SNAPCHAT_NURTURE)
                            selectedTab = Tab.DASHBOARD
                        },
                    )

                    Tab.STATS    -> StatsScreen(
                        vm           = statsVm,
                        onNavigateUp = { selectedTab = Tab.DASHBOARD },
                    )
                    Tab.ACCOUNTS -> AccountsScreen(
                        vm           = accountsVm,
                        onNavigateUp = { selectedTab = Tab.DASHBOARD },
                    )
                    Tab.SCHEDULE -> ScheduleScreen(
                        vm           = scheduleVm,
                        onNavigateUp = { selectedTab = Tab.DASHBOARD },
                    )
                }
            }
        }
    }

    // v1.2.9: Update dialog ở cấp MainScreen — luôn hiện đè lên mọi tab (không chỉ
    // Dashboard) vì state.updateInfo sống trong dashboardVm, ViewModel chung cho cả app.
    dashboardState.updateInfo?.let { info ->
        UpdateAvailableDialog(
            info             = info,
            downloadProgress = dashboardState.downloadProgress,
            onDismiss        = dashboardVm::dismissUpdate,
            onUpdate         = { dashboardVm.startUpdate() },
        )
    }
}
