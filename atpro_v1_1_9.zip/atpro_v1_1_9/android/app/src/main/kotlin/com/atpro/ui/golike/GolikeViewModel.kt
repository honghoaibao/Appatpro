package com.atpro.ui.golike

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.atpro.data.LocalRepository
import com.atpro.golike.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * GolikeViewModel — quản lý trạng thái toàn bộ tích hợp Golike.
 *
 * Dùng bởi:
 *   - DashboardScreen  → GolikeSummaryCard (summary coin/rank)
 *   - ConfigScreen     → EarnGolikeSection (login form + jobs)
 *
 * Mỗi Activity tạo instance riêng qua Factory; cả hai đều đọc/ghi
 * từ LocalRepository (Room DB) → tự đồng bộ qua persistent storage.
 */
class GolikeViewModel(
    private val repo: GolikeRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(GolikeUiState())
    val state: StateFlow<GolikeUiState> = _state.asStateFlow()

    init { loadSavedSession() }

    // ── Session ───────────────────────────────────────────────────────────────

    private fun loadSavedSession() {
        viewModelScope.launch {
            val token = repo.getSavedToken()
            if (token != null) {
                val saved = repo.getSavedUsername()
                _state.update { it.copy(isLoading = true, savedUsername = saved) }
                refreshUserInfo()
            }
        }
    }

    // ── Auth ─────────────────────────────────────────────────────────────────

    fun login(username: String, password: String) {
        if (username.isBlank() || password.isBlank()) {
            _state.update { it.copy(loginError = "Vui lòng nhập đầy đủ thông tin") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(isLoggingIn = true, loginError = null) }
            when (val result = repo.login(username, password)) {
                is GolikeResult.Success -> {
                    _state.update {
                        it.copy(
                            isLoggedIn    = true,
                            isLoggingIn   = false,
                            user          = result.data,
                            savedUsername = username,
                            loginError    = null,
                        )
                    }
                    refreshStats()
                    loadTikTokAccounts()
                }
                is GolikeResult.Error ->
                    _state.update { it.copy(isLoggingIn = false, loginError = result.message) }
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            repo.clearToken()
            _state.value = GolikeUiState()
        }
    }

    // ── Refresh ───────────────────────────────────────────────────────────────

    fun refreshUserInfo() {
        viewModelScope.launch {
            when (val result = repo.getMe()) {
                is GolikeResult.Success -> {
                    _state.update {
                        it.copy(user = result.data, isLoading = false, isLoggedIn = true)
                    }
                    refreshStats()
                    if (_state.value.tikTokAccounts.isEmpty()) loadTikTokAccounts()
                }
                is GolikeResult.Error -> {
                    if (result.code == 401) logout()
                    else _state.update { it.copy(isLoading = false) }
                }
            }
        }
    }

    fun refreshStats() {
        viewModelScope.launch {
            when (val result = repo.getStatistics()) {
                is GolikeResult.Success -> _state.update { it.copy(stats = result.data) }
                is GolikeResult.Error   -> { /* silent — stats not critical */ }
            }
        }
    }

    // ── TikTok accounts + jobs ────────────────────────────────────────────────

    fun loadTikTokAccounts() {
        viewModelScope.launch {
            _state.update { it.copy(isLoadingAccounts = true) }
            when (val result = repo.getTikTokAccounts()) {
                is GolikeResult.Success -> {
                    _state.update { it.copy(tikTokAccounts = result.data, isLoadingAccounts = false) }
                    result.data.forEach { acc -> loadJobsForAccount(acc.uniqueUsername) }
                }
                is GolikeResult.Error ->
                    _state.update { it.copy(isLoadingAccounts = false) }
            }
        }
    }

    private fun loadJobsForAccount(uniqueUsername: String) {
        viewModelScope.launch {
            when (val result = repo.getTikTokJobs(uniqueUsername)) {
                is GolikeResult.Success ->
                    _state.update { s ->
                        s.copy(tikTokJobs = s.tikTokJobs + (uniqueUsername to result.data))
                    }
                is GolikeResult.Error -> { /* no jobs for this account — ok */ }
            }
        }
    }

    /** Báo cáo hoàn thành job về server Golike. Theo dõi trạng thái loading + done. */
    fun completeJob(jobId: Int, uniqueUsername: String) {
        viewModelScope.launch {
            // Đánh dấu "đang xử lý"
            _state.update { it.copy(completingJobs = it.completingJobs + jobId) }
            val result = repo.completeTikTokJob(jobId, uniqueUsername)
            // Xong → thêm vào completedJobs, xóa khỏi completingJobs
            _state.update { s ->
                val success = result is GolikeResult.Success && result.data.success
                s.copy(
                    completingJobs = s.completingJobs - jobId,
                    completedJobs  = if (success) s.completedJobs + jobId else s.completedJobs,
                )
            }
            // Refresh danh sách jobs
            loadJobsForAccount(uniqueUsername)
        }
    }

    // ── Factory ───────────────────────────────────────────────────────────────

    class Factory(private val ctx: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val local = LocalRepository.getInstance(ctx.applicationContext)
            val repo  = GolikeRepository.getInstance(local)
            return GolikeViewModel(repo) as T
        }
    }
}

// ── UiState ───────────────────────────────────────────────────────────────────

data class GolikeUiState(
    val isLoading:         Boolean                        = false,
    val isLoggedIn:        Boolean                        = false,
    val isLoggingIn:       Boolean                        = false,
    val loginError:        String?                        = null,
    val savedUsername:     String                         = "",
    val user:              GolikeUserData?                = null,
    val stats:             StatisticsResponse?            = null,
    val tikTokAccounts:    List<TikTokAccountDto>         = emptyList(),
    val tikTokJobs:        Map<String, List<TikTokJobDto>> = emptyMap(),
    val isLoadingAccounts: Boolean                        = false,
    /** Job IDs đang được gửi hoàn thành lên server — hiển thị spinner. */
    val completingJobs:    Set<Int>                       = emptySet(),
    /** Job IDs đã hoàn thành thành công trong session hiện tại — hiển thị checkmark. */
    val completedJobs:     Set<Int>                       = emptySet(),
) {
    val coin:          Double get() = user?.coin ?: stats?.currentCoin ?: 0.0
    val rankName:      String get() = user?.userRank?.rankName ?: ""
    val tiktokHold:    Double get() = stats?.tiktok?.holdCoin    ?: 0.0
    val tiktokPending: Double get() = stats?.tiktok?.pendingCoin ?: 0.0
    val totalJobCount: Int    get() = tikTokJobs.values.sumOf { it.size }
    val displayName:   String get() = user?.name?.ifEmpty { user?.username } ?: savedUsername

    /** Hiển thị coin đẹp: "250" thay vì "250.0", "12.5" thay vì "12.500000". */
    fun formatCoin(value: Double): String =
        if (value == kotlin.math.floor(value)) value.toLong().toString()
        else "%.1f".format(value)
}
