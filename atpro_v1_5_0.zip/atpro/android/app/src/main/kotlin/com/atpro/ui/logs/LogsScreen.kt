package com.atpro.ui.logs

import androidx.compose.animation.*
import com.atpro.ui.theme.AtColors
import com.atpro.ui.theme.AtType
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.atpro.db.entity.FarmLogEntity
import java.text.SimpleDateFormat
import java.util.*

// ── Design tokens ─────────────────────────────────────────────
private val BgDark   = AtColors.Bg
private val CardDark = AtColors.Surface
private val Purple   = AtColors.Accent
private val Green    = AtColors.Success
private val Amber    = AtColors.Warning
private val RedBad   = AtColors.Danger
private val TextSec  = AtColors.TextSec
private val TextMuted= AtColors.TextMuted

private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

// ─────────────────────────────────────────────────────────────
//  Root screen
// ─────────────────────────────────────────────────────────────

@Composable
fun LogsScreen(vm: LogsViewModel, onNavigateUp: (() -> Unit)? = null) {
    val logs        by vm.logs.collectAsStateWithLifecycle()
    val levelFilter by vm.levelFilter.collectAsStateWithLifecycle()
    val clipboard   = LocalClipboardManager.current
    val listState   = rememberLazyListState()

    // Auto-scroll to top khi có log mới
    LaunchedEffect(logs.firstOrNull()?.id) {
        if (logs.isNotEmpty()) listState.animateScrollToItem(0)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .statusBarsPadding()
    ) {
        // ── Toolbar ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Nhật ký",
                style = AtType.Title.copy(fontSize = 22.sp), color = AtColors.TextPrim,
                modifier = Modifier.weight(1f),
            )
            AnimatedVisibility(
                visible = logs.isNotEmpty(),
                enter   = fadeIn(tween(200)) + scaleIn(tween(200)),
                exit    = fadeOut(tween(150)) + scaleOut(tween(150)),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Purple.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                    ) {
                        Text("${logs.size}", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(8.dp))
                }
            }
            // Copy all
            IconButton(onClick = {
                val text = logs.joinToString("\n") {
                    "[${timeFmt.format(Date(it.timestamp))}] ${it.message}"
                }
                clipboard.setText(AnnotatedString(text))
            }) {
                Icon(Icons.Rounded.ContentCopy, null, tint = TextSec, modifier = Modifier.size(20.dp))
            }
            // Clear all
            IconButton(onClick = vm::clearAll) {
                Icon(Icons.Rounded.DeleteSweep, null, tint = TextSec, modifier = Modifier.size(20.dp))
            }
        }

        // ── Level filter chips ──
        LazyRow(
            contentPadding        = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val levels = listOf(
                null                to ("Tất cả"   to Icons.Rounded.List),
                LOG_LEVEL_INFO      to ("Info"     to Icons.Rounded.Info),
                LOG_LEVEL_SUCCESS   to ("OK"       to Icons.Rounded.CheckCircle),
                LOG_LEVEL_WARNING   to ("Cảnh báo" to Icons.Rounded.Warning),
                LOG_LEVEL_ERROR     to ("Lỗi"      to Icons.Rounded.Error),
            )
            items(levels) { (lvl, meta) ->
                val (label, icon) = meta
                FilterChip(
                    selected      = levelFilter == lvl,
                    onClick       = { vm.setFilter(lvl) },
                    label         = { Text(label, fontSize = 12.sp) },
                    leadingIcon   = {
                        Icon(icon, null, modifier = Modifier.size(14.dp))
                    },
                    colors        = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = levelColor(lvl).copy(alpha = 0.15f),
                        selectedLabelColor     = levelColor(lvl),
                        selectedLeadingIconColor = levelColor(lvl),
                        containerColor         = CardDark,
                        labelColor             = TextSec,
                    ),
                    border        = FilterChipDefaults.filterChipBorder(
                        borderColor         = AtColors.Hairline,
                        selectedBorderColor = levelColor(lvl).copy(alpha = 0.4f),
                        enabled = true, selected = levelFilter == lvl,
                    ),
                )
            }
        }

        Spacer(Modifier.height(4.dp))

        // ── Log list ──
        AnimatedContent(
            targetState = logs.isEmpty(),
            transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(200)) },
            label = "logs_content",
        ) { empty ->
            if (empty) {
                EmptyLogsView()
            } else {
                LazyColumn(
                    state               = listState,
                    contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    reverseLayout       = false,
                ) {
                    items(logs, key = { it.id }) { log ->
                        LogRow(log)
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  Log row
// ─────────────────────────────────────────────────────────────

@Composable
private fun LogRow(log: FarmLogEntity) {
    val parsed = remember(log.message) { parseLogMessage(log.message) }
    val time   = remember(log.timestamp) { timeFmt.format(Date(log.timestamp)) }
    val color  = parsed.style.color

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CardDark)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.Top,
    ) {
        // Level accent bar
        Box(
            modifier = Modifier
                .width(3.dp)
                .height(if (log.accountId != null) 34.dp else 18.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(color)
        )
        Spacer(Modifier.width(8.dp))

        // Level icon
        Icon(
            parsed.style.icon, null,
            tint     = color.copy(alpha = 0.85f),
            modifier = Modifier
                .size(14.dp)
                .padding(top = 1.dp),
        )
        Spacer(Modifier.width(6.dp))

        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Tag badge — gọn gàng thay cho tiền tố "TAG:" lặp lại trong text.
                parsed.tag?.let { tag ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(color.copy(alpha = 0.14f))
                            .padding(horizontal = 5.dp, vertical = 1.dp),
                    ) {
                        Text(
                            text       = tag,
                            color      = color,
                            fontSize   = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 0.3.sp,
                        )
                    }
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    text       = parsed.body,
                    color      = Color(0xFFE5E7EB),
                    fontSize   = 12.sp,
                    lineHeight = 16.sp,
                    modifier   = Modifier.weight(1f),
                )
                Spacer(Modifier.width(6.dp))
                Text(time, color = TextMuted, fontSize = 10.sp)
            }
            log.accountId?.let {
                Spacer(Modifier.height(2.dp))
                Text("@$it", color = Purple.copy(alpha = 0.7f), fontSize = 10.sp)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  Helpers
// ─────────────────────────────────────────────────────────────

private fun levelColor(level: String?): Color = when (level) {
    LOG_LEVEL_SUCCESS -> Green
    LOG_LEVEL_WARNING -> Amber
    LOG_LEVEL_ERROR   -> RedBad
    else              -> Color(0xFF60A5FA) // INFO = blue
}

@Composable
private fun EmptyLogsView() {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            Icons.Rounded.Assignment,
            contentDescription = null,
            tint     = TextMuted.copy(alpha = 0.4f),
            modifier = Modifier.size(56.dp),
        )
        Spacer(Modifier.height(16.dp))
        Text(
            "Chưa có nhật ký nào",
            color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Nhật ký sẽ xuất hiện\nkhi farm bắt đầu chạy",
            color     = TextMuted,
            fontSize  = 13.sp,
            lineHeight = 20.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}
