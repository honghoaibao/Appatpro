package com.atpro.ui.dashboard

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import com.atpro.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.atpro.automation.FarmMode
import com.atpro.automation.LiveFarmStats
import com.atpro.network.UpdateInfo
import com.atpro.ui.accounts.AccountsActivity
import com.atpro.ui.config.ConfigActivity
import com.atpro.ui.logs.LogsActivity
import com.atpro.ui.stats.StatsActivity

// ── Design tokens ─────────────────────────────────────────────
private val BgDark      = Color(0xFF0D0D14)
private val CardDark    = Color(0xFF1A1A2E)
private val BorderDark  = Color(0xFF374151)
private val Purple      = Color(0xFF6C63FF)
private val Pink        = Color(0xFFEC4899)
private val Green       = Color(0xFF10B981)
private val Amber       = Color(0xFFF59E0B)
private val RedStop     = Color(0xFFEF4444)
private val TextPrim    = Color(0xFFEEEEF5)
private val TextSec     = Color(0xFF9CA3AF)
private val TextMuted   = Color(0xFF6B7280)

// ─────────────────────────────────────────────────────────────
//  Root Screen
// ─────────────────────────────────────────────────────────────

@Composable
fun DashboardScreen(vm: DashboardViewModel) {
    val state      by vm.uiState.collectAsStateWithLifecycle()
    val context    = LocalContext.current

    // [v1.1.5] Trạng thái thu nhỏ popup — reset mỗi khi farm kết thúc
    var isMinimized by remember { mutableStateOf(false) }
    LaunchedEffect(state.isStartingUp) {
        if (!state.isStartingUp) isMinimized = false
    }

    // [v1.0.5 → v1.2.9] Kiểm tra phiên bản mới — ĐÃ CHUYỂN lên MainScreen.kt để popup
    // không bị mất khi người dùng chuyển tab (DashboardScreen bị unmount khi rời tab Dashboard).

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .background(
                Brush.radialGradient(
                    colors = listOf(Purple.copy(alpha = 0.09f), Color.Transparent),
                )
            )
    ) {
        // [v1.0.4] Bỏ permission gate — mở thẳng Dashboard không cần cấp quyền trước.
        // Việc cấp quyền được thực hiện qua tab "Quyền" trong Cài đặt.
        AnimatedContent(
            targetState = state.isFarming,
            transitionSpec = {
                if (targetState) {
                    (fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 8 }) togetherWith
                        (fadeOut(tween(200)) + slideOutVertically(tween(200)) { -it / 8 })
                } else {
                    (fadeIn(tween(350)) + slideInVertically(tween(350)) { -it / 8 }) togetherWith
                        (fadeOut(tween(200)) + slideOutVertically(tween(200)) { it / 8 })
                }
            },
            label = "farming_state",
        ) { farming ->
            if (farming) FarmingView(state, vm)
            else         IdleView(state, vm)
        }

        // ── [v1.1.5] Startup status popup — có nút thu nhỏ ──────────────────
        if (state.isStartingUp && !isMinimized) {
            StartupStatusDialog(
                status     = state.startupStatus,
                isPaused   = state.isPaused,
                onPause    = vm::pause,
                onResume   = vm::resume,
                onStop     = vm::stop,
                onMinimize = { isMinimized = true },
            )
        }

        // ── [v1.1.5] Bubble thu nhỏ — hiện khi popup bị minimize ────────────
        AnimatedVisibility(
            visible = state.isStartingUp && isMinimized,
            enter   = fadeIn(tween(200)) + scaleIn(tween(220), initialScale = 0.6f),
            exit    = fadeOut(tween(150)) + scaleOut(tween(150)),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 20.dp),
        ) {
            MinimizedBubble(
                isPaused  = state.isPaused,
                onExpand  = { isMinimized = false },
            )
        }

        // [v1.0.5 → v1.2.9] Update dialog — ĐÃ CHUYỂN lên MainScreen.kt (xem comment ở trên).
    }
}

// ─────────────────────────────────────────────────────────────
//  [v1.1.9] Startup Status Dialog — redesigned popup
//  Cải tiến: accent strip, icon header, bố cục rõ ràng hơn
// ─────────────────────────────────────────────────────────────

@Composable
private fun StartupStatusDialog(
    status:    String,
    isPaused:  Boolean,
    onPause:   () -> Unit,
    onResume:  () -> Unit,
    onStop:    () -> Unit,
    onMinimize: () -> Unit,
) {
    Dialog(
        onDismissRequest = { /* không dismiss khi tap ngoài */ },
        properties = DialogProperties(
            dismissOnBackPress      = false,
            dismissOnClickOutside   = false,
            usePlatformDefaultWidth = false,
        ),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.72f)),
            contentAlignment = Alignment.Center,
        ) {
            Card(
                modifier  = Modifier.fillMaxWidth(0.82f),
                shape     = RoundedCornerShape(20.dp),
                colors    = CardDefaults.cardColors(containerColor = CardDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 24.dp),
                border    = BorderStroke(1.dp, Purple.copy(alpha = 0.25f)),
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {

                    // ── Accent strip — gradient ngang trên cùng ──────────────
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                            .background(
                                brush = Brush.horizontalGradient(
                                    listOf(Purple, Color(0xFF06B6D4))
                                )
                            )
                    )

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 18.dp),
                    ) {

                        // ── Header: icon badge + title + minimize ──────────────
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            // Icon badge với nền tròn
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Purple.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center,
                            ) {
                                AnimatedContent(
                                    targetState   = isPaused,
                                    transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
                                    label          = "header_icon",
                                ) { paused ->
                                    if (paused) {
                                        Icon(
                                            Icons.Rounded.Pause,
                                            contentDescription = null,
                                            tint     = Amber,
                                            modifier = Modifier.size(16.dp),
                                        )
                                    } else {
                                        CircularProgressIndicator(
                                            modifier    = Modifier.size(16.dp),
                                            color       = Purple,
                                            strokeWidth = 2.dp,
                                        )
                                    }
                                }
                            }

                            // Title
                            AnimatedContent(
                                targetState   = isPaused,
                                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
                                label          = "startup_title",
                            ) { paused ->
                                Column {
                                    Text(
                                        text       = if (paused) "Đã tạm dừng" else "Đang farm",
                                        color      = if (paused) Amber else Color.White,
                                        fontSize   = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                    )
                                    Text(
                                        text     = "AT PRO",
                                        color    = TextMuted,
                                        fontSize = 10.sp,
                                    )
                                }
                            }

                            Spacer(Modifier.weight(1f))

                            // Minimize button
                            IconButton(
                                onClick  = onMinimize,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(BorderDark),
                            ) {
                                Icon(
                                    Icons.Rounded.KeyboardArrowDown,
                                    contentDescription = "Thu nhỏ",
                                    tint     = TextMuted,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }

                        Spacer(Modifier.height(14.dp))

                        // ── Status text với left accent ────────────────────────
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.04f))
                                .padding(0.dp),
                        ) {
                            // Thin left accent bar
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(36.dp)
                                    .clip(RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp))
                                    .background(if (isPaused) Amber else Purple)
                            )
                            AnimatedContent(
                                targetState = status,
                                transitionSpec = {
                                    (fadeIn(tween(200)) + slideInVertically(tween(200)) { it / 4 }) togetherWith
                                        (fadeOut(tween(120)) + slideOutVertically(tween(120)) { -it / 4 })
                                },
                                label = "startup_status",
                            ) { msg ->
                                Text(
                                    text      = msg,
                                    color     = TextSec,
                                    fontSize  = 11.sp,
                                    modifier  = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 10.dp),
                                )
                            }
                        }

                        Spacer(Modifier.height(16.dp))

                        // ── Nút điều khiển ─────────────────────────────────────
                        Row(
                            modifier              = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            // Tạm dừng / Tiếp tục — outline style
                            OutlinedButton(
                                onClick  = if (isPaused) onResume else onPause,
                                modifier = Modifier.weight(1f).height(40.dp),
                                shape    = RoundedCornerShape(12.dp),
                                border   = BorderStroke(
                                    1.dp,
                                    if (isPaused) Green.copy(alpha = 0.7f) else Amber.copy(alpha = 0.5f),
                                ),
                                colors   = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isPaused) Green.copy(alpha = 0.08f)
                                                     else Amber.copy(alpha = 0.06f),
                                    contentColor   = if (isPaused) Green else Amber,
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp),
                            ) {
                                Icon(
                                    if (isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp),
                                )
                                Spacer(Modifier.width(5.dp))
                                Text(
                                    if (isPaused) "Tiếp tục" else "Tạm dừng",
                                    fontSize   = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                )
                            }

                            // Dừng farm — nhẹ nhàng hơn
                            OutlinedButton(
                                onClick  = onStop,
                                modifier = Modifier.weight(1f).height(40.dp),
                                shape    = RoundedCornerShape(12.dp),
                                border   = BorderStroke(1.dp, RedStop.copy(alpha = 0.6f)),
                                colors   = ButtonDefaults.outlinedButtonColors(
                                    containerColor = RedStop.copy(alpha = 0.08f),
                                    contentColor   = RedStop,
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp),
                            ) {
                                Icon(
                                    Icons.Rounded.Stop,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp),
                                )
                                Spacer(Modifier.width(5.dp))
                                Text("Dừng", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  [v1.0.9] Update Available Dialog
//  - Tự tải APK về máy và mở installer (không mở browser)
//  - Hiển thị progress bar khi đang tải
//  - Báo lỗi nếu tải thất bại
// ─────────────────────────────────────────────────────────────

@Composable
// v1.2.9: bỏ "private" — được gọi từ MainScreen.kt để hiển thị bất kể tab đang chọn
fun UpdateAvailableDialog(
    info:             UpdateInfo,
    downloadProgress: Int,           // -1=idle, 0–99=đang tải, -2=lỗi
    onDismiss:        () -> Unit,
    onUpdate:         () -> Unit,
) {
    val isDownloading = downloadProgress in 0..99
    val hasError      = downloadProgress == -2

    Dialog(
        onDismissRequest = { if (!isDownloading) onDismiss() },
        properties = DialogProperties(
            dismissOnBackPress      = !isDownloading,
            dismissOnClickOutside   = !isDownloading,
            usePlatformDefaultWidth = false,
        ),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.60f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication        = null,
                    onClick           = { if (!isDownloading) onDismiss() },
                ),
            contentAlignment = Alignment.Center,
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.88f)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication        = null,
                        onClick           = { /* absorb — prevent dismiss */ },
                    ),
                shape     = RoundedCornerShape(20.dp),
                colors    = CardDefaults.cardColors(containerColor = CardDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                border    = BorderStroke(1.dp, BorderDark),
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 24.dp),
                ) {
                    // ── Header ──
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(listOf(Purple, Pink))),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                Icons.Rounded.SystemUpdate,
                                contentDescription = null,
                                tint     = Color.White,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                        Column {
                            Text(
                                "Có phiên bản mới",
                                color      = Color.White,
                                fontSize   = 15.sp,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                info.releaseName,
                                color      = Purple,
                                fontSize   = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // ── Version badge ──
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Purple.copy(alpha = 0.07f))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment     = Alignment.CenterVertically,
                    ) {
                        Text("Phiên bản mới", color = TextSec, fontSize = 12.sp)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Purple.copy(alpha = 0.18f))
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                        ) {
                            Text(
                                info.tagName,
                                color      = Purple,
                                fontSize   = 12.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }

                    // ── Changelog (scrollable markdown) ──
                    if (info.body.isNotBlank()) {
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Thay đổi",
                            color      = TextSec,
                            fontSize   = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier   = Modifier.padding(bottom = 6.dp),
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 220.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(BgDark),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .verticalScroll(rememberScrollState())
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                            ) {
                                MarkdownChangelogText(markdown = info.body)
                            }
                        }
                    }

                    // ── [v1.0.9] Download progress bar ──
                    AnimatedVisibility(
                        visible = isDownloading || hasError,
                        enter   = fadeIn(tween(200)) + expandVertically(tween(250)),
                        exit    = fadeOut(tween(150)) + shrinkVertically(tween(200)),
                    ) {
                        Column {
                            Spacer(Modifier.height(14.dp))
                            if (isDownloading) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment     = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        "Đang tải APK...",
                                        color    = TextSec,
                                        fontSize = 11.sp,
                                    )
                                    Text(
                                        "$downloadProgress%",
                                        color      = Purple,
                                        fontSize   = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                    )
                                }
                                Spacer(Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { downloadProgress / 100f },
                                    modifier  = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color      = Purple,
                                    trackColor = BorderDark,
                                )
                            } else if (hasError) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Icon(
                                        Icons.Rounded.ErrorOutline,
                                        contentDescription = null,
                                        tint     = RedStop,
                                        modifier = Modifier.size(14.dp),
                                    )
                                    Text(
                                        "Tải thất bại. Kiểm tra mạng rồi thử lại.",
                                        color    = RedStop,
                                        fontSize = 11.sp,
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))

                    // ── Buttons ──
                    Row(
                        modifier              = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        OutlinedButton(
                            onClick  = onDismiss,
                            enabled  = !isDownloading,
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape    = RoundedCornerShape(12.dp),
                            colors   = ButtonDefaults.outlinedButtonColors(contentColor = TextSec),
                            border   = BorderStroke(1.dp, BorderDark),
                        ) {
                            Text("Để sau", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }

                        Button(
                            onClick  = onUpdate,
                            enabled  = !isDownloading,
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape    = RoundedCornerShape(12.dp),
                            colors   = ButtonDefaults.buttonColors(
                                containerColor         = Purple,
                                disabledContainerColor = Purple.copy(alpha = 0.5f),
                            ),
                        ) {
                            if (isDownloading) {
                                CircularProgressIndicator(
                                    modifier    = Modifier.size(14.dp),
                                    color       = Color.White,
                                    strokeWidth = 2.dp,
                                )
                            } else {
                                Icon(
                                    Icons.Rounded.FileDownload,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp),
                                )
                            }
                            Spacer(Modifier.width(6.dp))
                            Text(
                                if (isDownloading) "Đang tải..." else "Cập nhật",
                                fontSize   = 13.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  Idle view
// ─────────────────────────────────────────────────────────────

@Composable
private fun IdleView(state: DashboardUiState, vm: DashboardViewModel) {
    val context = LocalContext.current

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    AnimatedVisibility(
        visible = visible,
        enter   = fadeIn(tween(400)) + slideInVertically(tween(400, easing = EaseOut)) { it / 10 },
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // v1.2.7: Decorative radial glow top-right corner
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .offset(x = 80.dp, y = (-60).dp)
                    .align(Alignment.TopEnd)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Purple.copy(alpha = 0.07f), Color.Transparent)
                        )
                    )
            )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .statusBarsPadding()
        ) {
            Spacer(Modifier.height(32.dp))

            // ── Header ──
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (state.serviceConnected) Green.copy(alpha = 0.10f)
                            else CardDark.copy(alpha = 0.6f)
                        )
                        .border(
                            0.5.dp,
                            if (state.serviceConnected) Green.copy(alpha = 0.25f) else BorderDark,
                            RoundedCornerShape(20.dp),
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    StatusDot(online = state.serviceConnected)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text  = if (state.serviceConnected) "Sẵn sàng" else "Chưa bật dịch vụ",
                        color = if (state.serviceConnected) Green else TextMuted,
                        fontSize   = 13.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
                Spacer(Modifier.weight(1f))
                IconButton(
                    onClick  = { context.startActivity(Intent(context, ConfigActivity::class.java)) },
                    modifier = Modifier.size(36.dp),
                ) {
                    Icon(
                        Icons.Rounded.Settings,
                        contentDescription = "Cài đặt",
                        tint     = TextMuted,
                        modifier = Modifier.size(20.dp),
                    )
                }
                Spacer(Modifier.width(4.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .border(0.75.dp, Purple.copy(alpha = 0.30f), RoundedCornerShape(10.dp))
                        .padding(1.5.dp),
                ) {
                    AppLogo()
                }
            }

            Spacer(Modifier.weight(1f))

            // ── Account / list count ──
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth(),
            ) {
                AnimatedContent(
                    targetState = state.displayCount,
                    transitionSpec = {
                        (fadeIn(tween(300)) + slideInVertically(tween(300)) { -it / 2 }) togetherWith
                            (fadeOut(tween(200)) + slideOutVertically(tween(200)) { it / 2 })
                    },
                    label = "count_anim",
                ) { count ->
                    Text(
                        text  = "$count",
                        style = androidx.compose.ui.text.TextStyle(
                            brush      = Brush.verticalGradient(listOf(Color.White, Color(0xFFC9C9DE))),
                            fontSize   = 72.sp,
                            fontWeight = FontWeight.ExtraBold,
                            lineHeight = 72.sp,
                        ),
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text  = when {
                        state.farmMode == FarmMode.SELECTED_LIST && state.displayCount == 0 ->
                            "tài khoản trong danh sách"
                        state.displayCount == 0 -> "tài khoản"
                        state.farmMode == FarmMode.SELECTED_LIST -> "tài khoản trong danh sách"
                        else -> "tài khoản hoạt động"
                    },
                    color    = TextMuted,
                    fontSize = 15.sp,
                )
            }

            Spacer(Modifier.height(24.dp))

            // ── Farm mode toggle — ẩn ở chế độ Demo [v1.2.3/v1.2.4] ──
            AnimatedVisibility(
                visible = !state.isDemoMode,
            ) {
                Column {
                    FarmModeToggle(
                        selected  = state.farmMode,
                        onSelect  = vm::setFarmMode,
                    )
                    AnimatedVisibility(
                        visible = state.farmMode == FarmMode.SELECTED_LIST,
                        enter   = fadeIn(tween(250)) + expandVertically(tween(300, easing = EaseOut)),
                        exit    = fadeOut(tween(200)) + shrinkVertically(tween(250, easing = EaseIn)),
                    ) {
                        Column {
                            Spacer(Modifier.height(12.dp))
                            AccountListInput(
                                value     = state.customAccounts,
                                onChanged = vm::setCustomAccounts,
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            // ── Start button — phân nhánh theo serviceMode [v1.2.4] ──
            when (state.serviceMode) {
                com.atpro.automation.ServiceMode.FARM -> StartButton(
                    enabled = state.canStart, hint = state.startHint, onClick = vm::startFarm,
                    labelText = "Bắt đầu nuôi TikTok",
                )
                com.atpro.automation.ServiceMode.TASK -> {
                    if (com.atpro.security.AppConstants.GOLIKE_ENABLED && state.isGolikeLoggedIn) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                                .background(androidx.compose.ui.graphics.Color(0xFF1A1030))
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column {
                                Text("Số dư Golike", color = TextMuted, fontSize = 10.sp)
                                Text(
                                    "%.0f xu".format(state.golikeCoin),
                                    color = Green, fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Chờ duyệt", color = TextMuted, fontSize = 10.sp)
                                Text(
                                    "%.0f xu".format(state.golikeHoldCoin),
                                    color = Amber, fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    StartButton(
                        enabled = state.canStart, hint = state.startHint, onClick = vm::startTask,
                        labelText = "Bắt đầu làm nhiệm vụ",
                        accentColor = androidx.compose.ui.graphics.Color(0xFF7C3AED),
                    )
                }
                com.atpro.automation.ServiceMode.FACEBOOK_NURTURE -> StartButton(
                    enabled = state.canStart, hint = state.startHint, onClick = vm::startFacebookNurture,
                    labelText = "Bắt đầu nuôi Facebook",
                    accentColor = androidx.compose.ui.graphics.Color(0xFF1877F2),
                )
                com.atpro.automation.ServiceMode.X_NURTURE -> StartButton(
                    enabled = state.canStart, hint = state.startHint, onClick = vm::startXNurture,
                    labelText = "Bắt đầu nuôi X",
                    accentColor = androidx.compose.ui.graphics.Color(0xFF1D9BF0),
                )
                com.atpro.automation.ServiceMode.INSTAGRAM_NURTURE -> StartButton(
                    enabled = state.canStart, hint = state.startHint, onClick = vm::startInstagramNurture,
                    labelText = "Bắt đầu nuôi Instagram",
                    accentColor = androidx.compose.ui.graphics.Color(0xFF833AB4),
                )
                com.atpro.automation.ServiceMode.THREADS_NURTURE -> StartButton(
                    enabled = state.canStart, hint = state.startHint, onClick = vm::startThreadsNurture,
                    labelText = "Bắt đầu nuôi Threads",
                    accentColor = androidx.compose.ui.graphics.Color(0xFFAAAAAA),
                )
                com.atpro.automation.ServiceMode.SNAPCHAT_NURTURE -> StartButton(
                    enabled = state.canStart, hint = state.startHint, onClick = vm::startSnapchatNurture,
                    labelText = "Bắt đầu nuôi Snapchat",
                    accentColor = androidx.compose.ui.graphics.Color(0xFFFFFC00),
                )
            }

            Spacer(Modifier.weight(1f))

            // [v1.1.5] ShortcutRow đã được chuyển sang bottom NavigationBar — không cần ở đây nữa.

            Spacer(Modifier.height(32.dp))
        }  // Column
        }  // Box (decorative glow wrapper)
    }
}

// ─────────────────────────────────────────────────────────────
//  Farming view
// ─────────────────────────────────────────────────────────────

@Composable
private fun FarmingView(state: DashboardUiState, vm: DashboardViewModel) {
    val stats = state.liveStats
    // v1.2.7: Animated glow orb background when farming
    val inf = rememberInfiniteTransition(label = "farm_bg")
    val glowIntensity by inf.animateFloat(
        initialValue  = 0.04f,
        targetValue   = if (state.isPaused) 0.04f else 0.10f,
        animationSpec = infiniteRepeatable(tween(2500, easing = EaseInOut), RepeatMode.Reverse),
        label         = "glow_intensity",
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // Decorative glow at top-left
        Box(
            modifier = Modifier
                .size(280.dp)
                .offset(x = (-60).dp, y = (-40).dp)
                .background(Brush.radialGradient(
                    colors = listOf(
                        (if (state.isPaused) Amber else Green).copy(alpha = glowIntensity),
                        Color.Transparent,
                    )
                ))
        )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .statusBarsPadding()
    ) {
        Spacer(Modifier.height(32.dp))

        // ── Header ──
        Row(verticalAlignment = Alignment.CenterVertically) {
            PulseDot()
            Spacer(Modifier.width(8.dp))
            AnimatedContent(
                targetState = state.isPaused,
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
                label = "pause_label",
            ) { paused ->
                Text(
                    text  = if (paused) "Đang tạm dừng" else "Đang farm",
                    color = if (paused) Amber else Green,
                    fontSize   = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Spacer(Modifier.weight(1f))
            TextButton(
                onClick = vm::stop,
                colors  = ButtonDefaults.textButtonColors(contentColor = RedStop),
            ) {
                Icon(Icons.Rounded.Stop, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Dừng", fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(Modifier.weight(1f))

        // ── Current account ──
        CurrentAccountCard(stats)

        Spacer(Modifier.height(32.dp))

        // ── Stats grid ──
        AnimatedVisibility(
            visible = stats.account.isNotEmpty(),
            enter   = fadeIn(tween(400)) + expandVertically(tween(400)),
        ) {
            StatsGrid(stats)
        }

        Spacer(Modifier.weight(1f))

        // ── Pause / Resume ──
        PauseResumeButton(
            isPaused = state.isPaused,
            onPause  = vm::pause,
            onResume = vm::resume,
        )

        Spacer(Modifier.height(32.dp))
    }  // Column
    }  // Box (farming glow bg)
}

// ─────────────────────────────────────────────────────────────
//  Farm mode toggle
// ─────────────────────────────────────────────────────────────

@Composable
private fun FarmModeToggle(selected: FarmMode, onSelect: (FarmMode) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardDark),
    ) {
        ModeTab(
            label    = "Toàn bộ máy",
            icon     = Icons.Rounded.PhoneAndroid,
            active   = selected == FarmMode.ALL_LOCAL,
            modifier = Modifier.weight(1f),
            onClick  = { onSelect(FarmMode.ALL_LOCAL) },
        )
        ModeTab(
            label    = "Danh sách chọn",
            icon     = Icons.Rounded.FormatListBulleted,
            active   = selected == FarmMode.SELECTED_LIST,
            modifier = Modifier.weight(1f),
            onClick  = { onSelect(FarmMode.SELECTED_LIST) },
        )
    }
}

@Composable
private fun ModeTab(
    label: String,
    icon: ImageVector,
    active: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val bgColor by animateColorAsState(
        targetValue  = if (active) Purple else Color.Transparent,
        animationSpec = tween(200),
        label        = "tab_bg",
    )
    val contentColor by animateColorAsState(
        targetValue  = if (active) Color.White else TextMuted,
        animationSpec = tween(200),
        label        = "tab_fg",
    )
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(icon, null, tint = contentColor, modifier = Modifier.size(14.dp))
            Text(
                label,
                color      = contentColor,
                fontSize   = 13.sp,
                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  Account list input (SELECTED_LIST mode)
// ─────────────────────────────────────────────────────────────

@Composable
private fun AccountListInput(value: String, onChanged: (String) -> Unit) {
    Column {
        Text(
            "Danh sách tài khoản cần nuôi",
            color    = TextSec,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 6.dp),
        )
        OutlinedTextField(
            value         = value,
            onValueChange = onChanged,
            modifier      = Modifier
                .fillMaxWidth()
                .heightIn(min = 100.dp, max = 200.dp),
            placeholder = {
                Text(
                    "username1\nusername2\n@username3",
                    color = Color(0xFF4B5563),
                    fontSize = 13.sp,
                )
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            shape  = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor   = CardDark,
                unfocusedContainerColor = CardDark,
                focusedBorderColor      = Purple,
                unfocusedBorderColor    = Color.Transparent,
                focusedTextColor        = Color.White,
                unfocusedTextColor      = Color.White,
            ),
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Mỗi dòng một tài khoản. @ tự động bỏ qua.",
            color    = TextMuted,
            fontSize = 11.sp,
        )
    }
}

// ─────────────────────────────────────────────────────────────
//  Components
// ─────────────────────────────────────────────────────────────

@Composable
// v1.2.7: AppLogo với animated glow ring
private fun AppLogo() {
    val inf = rememberInfiniteTransition(label = "logo_glow")
    val alpha by inf.animateFloat(
        initialValue  = 0.2f,
        targetValue   = 0.5f,
        animationSpec = infiniteRepeatable(tween(1800, easing = EaseInOut), RepeatMode.Reverse),
        label         = "logo_alpha",
    )
    Box(
        modifier = Modifier
            .size(34.dp)
            .border(1.dp, Purple.copy(alpha = alpha), RoundedCornerShape(9.dp))
            .padding(1.dp),
    ) {
        Image(
            painter            = painterResource(R.drawable.icon_app),
            contentDescription = "AT PRO",
            contentScale       = ContentScale.Crop,
            modifier           = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(8.dp)),
        )
    }
}

// ─────────────────────────────────────────────────────────────
//  [v1.1.5] MinimizedBubble — bubble tròn khi popup được thu nhỏ
//  Hiển thị logo app + pulse ring để báo farm vẫn đang chạy.
//  Tap để mở lại popup StartupStatusDialog.
// ─────────────────────────────────────────────────────────────

@Composable
private fun MinimizedBubble(
    isPaused: Boolean,
    onExpand: () -> Unit,
) {
    val inf    = rememberInfiniteTransition(label = "bubble_pulse")
    val pulse  by inf.animateFloat(
        initialValue  = 0.85f,
        targetValue   = 1.15f,
        animationSpec = infiniteRepeatable(
            tween(900, easing = EaseInOut),
            RepeatMode.Reverse,
        ),
        label = "bubble_scale",
    )
    val ringAlpha by inf.animateFloat(
        initialValue  = 0.55f,
        targetValue   = 0f,
        animationSpec = infiniteRepeatable(
            tween(900, easing = EaseInOut),
            RepeatMode.Reverse,
        ),
        label = "ring_alpha",
    )

    Box(contentAlignment = Alignment.Center) {
        // Pulse ring
        Box(
            modifier = Modifier
                .size(70.dp)
                .scale(pulse)
                .clip(CircleShape)
                .background(
                    (if (isPaused) Amber else Purple).copy(alpha = ringAlpha * 0.35f),
                ),
        )
        // Bubble chính
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            if (isPaused) Amber.copy(alpha = 0.9f) else Purple.copy(alpha = 0.9f),
                            CardDark,
                        ),
                    ),
                )
                .border(1.5.dp, if (isPaused) Amber.copy(alpha = 0.5f) else Purple.copy(alpha = 0.5f), CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication        = null,
                    onClick           = onExpand,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter            = painterResource(R.drawable.icon_app),
                contentDescription = "Mở lại farm status",
                contentScale       = ContentScale.Crop,
                modifier           = Modifier
                    .size(38.dp)
                    .clip(CircleShape),
            )
        }
    }
}

@Composable
private fun StatusDot(online: Boolean) {
    val color by animateColorAsState(
        targetValue  = if (online) Green else TextMuted,
        animationSpec = tween(300),
        label        = "status_dot",
    )
    // v1.2.7: Breathing glow khi online
    val inf = rememberInfiniteTransition(label = "dot_breath")
    val scale by inf.animateFloat(
        initialValue  = 1f,
        targetValue   = if (online) 1.25f else 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = EaseInOut), RepeatMode.Reverse),
        label         = "dot_scale",
    )
    Box(
        modifier = Modifier
            .size(8.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(color)
    )
}

@Composable
private fun PulseDot() {
    val inf = rememberInfiniteTransition(label = "pulse")
    val alpha by inf.animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1000, easing = EaseInOut), RepeatMode.Reverse,
        ),
        label = "alpha",
    )
    Box(
        modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(Green.copy(alpha = alpha))
    )
}

@Composable
private fun StartButton(
    enabled:     Boolean,
    hint:        String?,
    onClick:     () -> Unit,
    labelText:   String                                    = "Bắt đầu nuôi TikTok",
    accentColor: androidx.compose.ui.graphics.Color       = Purple,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue   = if (isPressed) 0.97f else 1f,
        animationSpec = tween(100),
        label         = "btn_scale",
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // v1.2.7: Gradient button với glow effect
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .scale(scale)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    if (enabled)
                        Brush.horizontalGradient(
                            listOf(
                                accentColor,
                                accentColor.copy(red = (accentColor.red + 0.08f).coerceAtMost(1f),
                                                 blue = (accentColor.blue + 0.06f).coerceAtMost(1f)),
                            )
                        )
                    else Brush.horizontalGradient(listOf(BorderDark, BorderDark))
                )
                .clickable(
                    enabled           = enabled,
                    interactionSource = interactionSource,
                    indication        = null,
                    onClick           = onClick,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Row(
                verticalAlignment         = Alignment.CenterVertically,
                horizontalArrangement     = Arrangement.Center,
            ) {
                Icon(
                    Icons.Rounded.PlayArrow,
                    null,
                    tint     = if (enabled) Color.White else TextMuted,
                    modifier = Modifier.size(22.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    labelText,
                    fontSize   = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color      = if (enabled) Color.White else TextMuted,
                )
            }
        }
        AnimatedVisibility(
            visible = hint != null,
            enter   = fadeIn(tween(200)) + expandVertically(tween(200)),
            exit    = fadeOut(tween(150)) + shrinkVertically(tween(150)),
        ) {
            Column {
                Spacer(Modifier.height(10.dp))
                Text(hint ?: "", color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun CurrentAccountCard(stats: LiveFarmStats) {
    val progress = if (stats.total > 0) stats.index.toFloat() / stats.total else 0f
    val animProgress by animateFloatAsState(
        targetValue   = progress,
        animationSpec = tween(500, easing = EaseOut),
        label         = "progress",
    )
    // v1.2.7: Slow rotating border glow
    val inf = rememberInfiniteTransition(label = "card_glow")
    val glowAlpha by inf.animateFloat(
        initialValue  = 0.25f,
        targetValue   = 0.55f,
        animationSpec = infiniteRepeatable(tween(2200, easing = EaseInOut), RepeatMode.Reverse),
        label         = "card_glow_a",
    )

    // v1.2.7: Subtle glowing card wrapper
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CardDark.copy(alpha = 0.5f))
            .border(
                0.75.dp,
                Purple.copy(alpha = glowAlpha),
                RoundedCornerShape(20.dp),
            )
            .padding(vertical = 20.dp, horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth(),
    ) {
        AnimatedContent(
            targetState = stats.account,
            transitionSpec = {
                (fadeIn(tween(300)) + slideInVertically(tween(300)) { it / 4 }) togetherWith
                    (fadeOut(tween(200)) + slideOutVertically(tween(200)) { -it / 4 })
            },
            label = "account_name",
        ) { acc ->
            Text(
                "@${acc.ifEmpty { "..." }}",
                color      = Color.White,
                fontSize   = 28.sp,
                fontWeight = FontWeight.Bold,
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.Center) {
            Text("${stats.index}", color = Purple, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(" / ", color = TextMuted, fontSize = 15.sp)
            Text("${stats.total}", color = TextMuted, fontSize = 15.sp)
        }
        Spacer(Modifier.height(16.dp))
        LinearProgressIndicator(
            progress = { animProgress },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color      = Purple,
            trackColor = BorderDark,
        )
    }
    }  // Box
}

@Composable
private fun StatsGrid(stats: LiveFarmStats) {
    val mins = stats.remainingSecs / 60
    val secs = stats.remainingSecs % 60
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatBox("${stats.videos}",  "Video",  Icons.Rounded.PlayCircle,  Purple, Modifier.weight(1f))
        StatBox("${stats.likes}",   "Thích",  Icons.Rounded.Favorite,    Pink,   Modifier.weight(1f))
        StatBox("${stats.follows}", "Theo",   Icons.Rounded.PersonAdd,   Green,  Modifier.weight(1f))
        StatBox(
            value    = "$mins:${secs.toString().padStart(2, '0')}",
            label    = "Còn lại",
            icon     = Icons.Rounded.Timer,
            color    = Amber,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun StatBox(
    value: String,
    label: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(color.copy(alpha = 0.08f))
            .border(1.dp, color.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
            .padding(vertical = 16.dp),
    ) {
        Icon(icon, null, tint = color.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
        Spacer(Modifier.height(6.dp))
        Text(value, color = color, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(4.dp))
        Text(label, color = TextSec, fontSize = 11.sp)
    }
}

@Composable
private fun PauseResumeButton(isPaused: Boolean, onPause: () -> Unit, onResume: () -> Unit) {
    val contentColor by animateColorAsState(
        targetValue  = if (isPaused) Green else TextSec,
        animationSpec = tween(200),
        label        = "pause_btn_color",
    )
    OutlinedButton(
        onClick  = if (isPaused) onResume else onPause,
        modifier = Modifier.fillMaxWidth().height(48.dp),
        shape    = RoundedCornerShape(14.dp),
        border   = BorderStroke(1.dp, SolidColor(BorderDark)),
        colors   = ButtonDefaults.outlinedButtonColors(contentColor = contentColor),
    ) {
        Icon(
            if (isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
            null,
            modifier = Modifier.size(16.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text       = if (isPaused) "Tiếp tục" else "Tạm dừng",
            fontWeight = FontWeight.SemiBold,
        )
    }
}


@Composable
private fun ShortcutRow() {
    val context = LocalContext.current
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        ShortcutTile(
            icon     = Icons.Rounded.ManageAccounts,
            label    = "Tài khoản",
            accent   = Purple,
            modifier = Modifier.weight(1f),
        ) { context.startActivity(Intent(context, AccountsActivity::class.java)) }
        ShortcutTile(
            icon     = Icons.Rounded.BarChart,
            label    = "Thống kê",
            accent   = Color(0xFF22D3EE),
            modifier = Modifier.weight(1f),
        ) { context.startActivity(Intent(context, StatsActivity::class.java)) }
        ShortcutTile(
            icon     = Icons.Rounded.Assignment,
            label    = "Nhật ký",
            accent   = Pink,
            modifier = Modifier.weight(1f),
        ) { context.startActivity(Intent(context, LogsActivity::class.java)) }
    }
}

@Composable
private fun ShortcutTile(
    icon: ImageVector,
    label: String,
    accent: Color = Purple,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue   = if (isPressed) 0.94f else 1f,
        animationSpec = tween(100),
        label         = "tile_scale",
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .scale(scale)
            .clip(RoundedCornerShape(14.dp))
            .background(CardDark)
            .border(0.5.dp, accent.copy(alpha = 0.18f), RoundedCornerShape(14.dp))
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .padding(vertical = 14.dp),
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(accent.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(17.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = TextSec, fontSize = 11.sp)
    }
}

// Helper — không cần thiết nữa vì đã import androidx.compose.ui.graphics.SolidColor

// ─────────────────────────────────────────────────────────────
//  Markdown Changelog Renderer
//  Hỗ trợ: # ## ###, **bold**, - bullet, dòng trống
// ─────────────────────────────────────────────────────────────

private val ChangelogPurple = Color(0xFF6C63FF)
private val ChangelogWhite  = Color.White
private val ChangelogSec    = Color(0xFF9CA3AF)

@Composable
private fun MarkdownChangelogText(markdown: String) {
    val lines = markdown.lines()
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        lines.forEach { raw ->
            val line = raw.trimEnd()
            when {
                line.startsWith("### ") -> {
                    Text(
                        text       = line.removePrefix("### "),
                        color      = ChangelogWhite,
                        fontSize   = 12.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 18.sp,
                        modifier   = Modifier.padding(top = 6.dp, bottom = 1.dp),
                    )
                }
                line.startsWith("## ") -> {
                    Text(
                        text       = line.removePrefix("## "),
                        color      = ChangelogWhite,
                        fontSize   = 13.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 19.sp,
                        modifier   = Modifier.padding(top = 8.dp, bottom = 2.dp),
                    )
                }
                line.startsWith("# ") -> {
                    Text(
                        text       = line.removePrefix("# "),
                        color      = ChangelogWhite,
                        fontSize   = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        lineHeight = 20.sp,
                        modifier   = Modifier.padding(top = 10.dp, bottom = 2.dp),
                    )
                }
                line.startsWith("- ") || line.startsWith("* ") -> {
                    Row(modifier = Modifier.padding(top = 1.dp, bottom = 1.dp)) {
                        Text(
                            text  = "•  ",
                            color = ChangelogPurple,
                            fontSize = 11.sp,
                        )
                        Text(
                            text       = parseInlineBold(line.substring(2)),
                            color      = ChangelogSec,
                            fontSize   = 11.sp,
                            lineHeight = 16.sp,
                        )
                    }
                }
                line.isBlank() -> {
                    Spacer(Modifier.height(4.dp))
                }
                else -> {
                    Text(
                        text       = parseInlineBold(line),
                        color      = ChangelogSec,
                        fontSize   = 11.sp,
                        lineHeight = 16.sp,
                    )
                }
            }
        }
    }
}

/** Chuyển **text** thành AnnotatedString có in đậm trắng. */
private fun parseInlineBold(text: String): AnnotatedString {
    val boldPattern = Regex("""\*\*(.+?)\*\*""")
    return buildAnnotatedString {
        var cursor = 0
        for (match in boldPattern.findAll(text)) {
            // Phần trước bold
            append(text.substring(cursor, match.range.first))
            // Phần bold
            withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = ChangelogWhite)) {
                append(match.groupValues[1])
            }
            cursor = match.range.last + 1
        }
        // Phần còn lại
        append(text.substring(cursor))
    }
}
